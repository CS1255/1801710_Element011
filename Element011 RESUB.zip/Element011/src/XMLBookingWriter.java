/*************************************************************************/
//* Name: SID: 1801710                                                  *//
//* Task: Element 010 - Hotel Management System                         *//
//* Description: XML Booking Writer		                                *//
//* Date: 17/05/2020                                                    *//
//*                                                                     *//
/************************************************************************/

//import packages
import javax.xml.parsers.DocumentBuilderFactory;
import javax.swing.JOptionPane;
import javax.xml.parsers.DocumentBuilder;
import javax.xml.transform.Transformer;
import javax.xml.transform.TransformerFactory;
import javax.xml.transform.dom.DOMSource;
import javax.xml.transform.stream.StreamResult;
import org.w3c.dom.Attr;
import org.w3c.dom.Document;
import org.w3c.dom.Element;
import java.io.File;

//start class
//Extends XMLWriter as it is part of the XMLBookingWriter Class
public class XMLBookingWriter extends XMLWriter
{
	//Elements for Booking Writer --> Client Details
	//------------------------------------------------------------
	private Element root_Element;
	private Element booking;
	private Element apartment_Name;
	private Element first_Name;
	private Element last_Name;
	private Element max_Guests;
	private Element start_Date;
	private Element end_Date;
	private Element catering;
	//------------------------------------------------------------
	
	//Attribute for Booking Writer --> Client Details
	//------------------------------------------------------------
	private Attr attr;
	//------------------------------------------------------------
	
	//Transformers, DOMSource and StreamResult for XML
	//------------------------------------------------------------
	private TransformerFactory transformer_Factory;
	private Transformer transformer;
	private DOMSource source;
	private StreamResult result;
	private StreamResult console_Result;
	//------------------------------------------------------------
	
	//Integer for Booking ID --> Client
	//------------------------------------------------------------
	private int booking_ID = 101;
	//------------------------------------------------------------
	//================================================================================================================================================================================
	
	//Constructor --> BookingWriter
	public void bookingWriter(Document doc, String filenameToWrite, String clientApartmentName, String clientFirstName, String clientLastName, String maxGuests, 
			String bookingStartDate, String bookingEndDate, String bookingCatering)
	{
		try
		{
			//ELEMENT --> Root
			root_Element = doc.createElement("clientsbookings");
			doc.appendChild(root_Element);
			
			//ELEMENT --> Bookings
			booking = doc.createElement("clientbooking");
			root_Element.appendChild(booking);
			
			//Attribute becomes Element
			attr = doc.createAttribute("ID");
			
			//BOOKING ID --> Security
			booking_ID = booking_ID + 1;
			attr.setValue(Integer.toString(booking_ID));
			JOptionPane.showMessageDialog(null, "Your booking ID is: " + booking_ID);
			
			booking.setAttributeNode(attr);
			
			//ELEMENT --> Bookings: Apartment Name
			apartment_Name = doc.createElement("apartmentname");
			apartment_Name.appendChild(doc.createTextNode(clientApartmentName));
			booking.appendChild(apartment_Name);
			
			//ELEMENT --> Bookings: FirstName
			first_Name = doc.createElement("firstname");
			first_Name.appendChild(doc.createTextNode(clientFirstName));
			booking.appendChild(first_Name);
			
			//ELEMENT --> Bookings: Last Name
			last_Name = doc.createElement("lastname");
			last_Name.appendChild(doc.createTextNode(clientLastName));
			booking.appendChild(last_Name);
			
			//ELEMENT --> Bookings: Max Guests
			max_Guests = doc.createElement("numberguests");
			max_Guests.appendChild(doc.createTextNode(maxGuests));
			booking.appendChild(max_Guests);
			
			//ELEMENT --> Bookings: Start Date
			start_Date = doc.createElement("startdate");
			start_Date.appendChild(doc.createTextNode(bookingStartDate));
			booking.appendChild(start_Date);
			
			//ELEMENT --> Bookings: End Date
			end_Date = doc.createElement("enddate");
			end_Date.appendChild(doc.createTextNode(bookingEndDate));
			booking.appendChild(end_Date);
			
			//ELEMENT --> Bookings: Catering
			catering = doc.createElement("catering");
			catering.appendChild(doc.createTextNode(bookingCatering));
			booking.appendChild(catering);
			
			//Writes content into XML File
			transformer_Factory = TransformerFactory.newInstance();
			transformer = transformer_Factory.newTransformer();

			source = new DOMSource(doc);
			
			result = new StreamResult(new File(filenameToWrite));
			transformer.transform(source, result);
			
			//TESTING --> Output
			console_Result = new StreamResult(System.out);
			transformer.transform(source, console_Result);
		}
		catch (Exception e)
		{
			e.printStackTrace();
		}//end try...catch
	}//end method
}//end class

