/*************************************************************************/
//* Name: SID: 1801710                                                  *//
//* Task: Element 010 - Hotel Management System                         *//
//* Description: Hotel Management Main Code                             *//
//* Date: 17/05/2020                                                    *//
//*                                                                     *//
/************************************************************************/

//import packages
import java.awt.*;
import java.awt.event.*;
import java.io.File;
import javax.swing.*;
import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;
import org.w3c.dom.Document;
import org.w3c.dom.Element;
import org.w3c.dom.Node;
import org.w3c.dom.NodeList;

//start class
//Extends JFrame as it is part of the HotelManagement Class, 
//implements ActionListener for objects to receive actions
public class MyHotelManagement extends JFrame implements ActionListener
{
	//FlowLayout and BorderLayouts for HotelManagement
	private final FlowLayout FlowLayout1;
	private final FlowLayout FlowLayout2;
	private final FlowLayout FlowLayout3;
	private final BorderLayout BorderLayout1;
	private final BorderLayout BorderLayout2;
	private final BorderLayout BorderLayout2_B;
	//------------------------------------------------------------
	
	//BorderLayout and FlowLayout for Booking
	private FlowLayout FlowLayout_booking1; //Creates the Booking Frame
	private FlowLayout FlowLayout_booking2; //Used for Booking Selections Panel (Booking Panel 3)
	private BorderLayout BorderLayout_booking1; //Used for Booking Panel 1
	private BorderLayout BorderLayout_booking2; //Used for Apartments Panel (Booking Panel 2)
	private BorderLayout BorderLayout_booking3; //Used for Booking Selections Panel (Booking Panel 3), done through labels and text fields
	private BorderLayout BorderLayout_booking3A;
	private BorderLayout BorderLayout_booking3B;
	//------------------------------------------------------------
	
	//JPanels for HotelManagement
	private final JPanel Panel1;
	private final JPanel Panel2;
	private final JPanel Panel2_B;
	private final JPanel Panel3;
	//------------------------------------------------------------
	
	//JPanels for apartment booking
	private JPanel Panel_booking1;
	private JPanel Panel_booking2;
	private JPanel Panel_booking3;
	private JPanel Panel_booking3A;
	private JPanel Panel_booking3B;
	//------------------------------------------------------------
	
	//JLabels for apartment booking
	private JLabel Apt_SelectionLabel; //label for apartment selections
	private JLabel Apt_FirstNameLabel; //label for first name
	private JLabel Apt_LastNameLabel; //label for last name
	private JLabel Apt_MaxGuestsLabel; //label for max amount of guests
	private JLabel Apt_CateringBookingLabel; //label for catering
	private JLabel Apt_StartDateLabel; //label for start date
	private JLabel Apt_EndDateLabel; //label for end date
	//------------------------------------------------------------
	
	//JTextFields for apartment booking
	private JTextField Apt_SelectionTextField; //text field for apartment selections
	private JTextField Apt_FirstNameTextField; //text field for first name
	private JTextField Apt_LastNameTextField; //text field for last name
	private JTextField Apt_MaxGuestsTextField; //text field for max amount of guests
	private JTextField Apt_CateringBookingTextField; //text field for catering
	private JTextField Apt_StartDateTextField; //text field for start date
	private JTextField Apt_EndDateTextField; //text field for end date
	//------------------------------------------------------------
	
	//JLabel for login details
	private final JLabel Login_Label;
	private final JLabel Username_Label;
	private final JLabel Password_Label;
	//------------------------------------------------------------
	
	//JLabels for the Client Options
	private JLabel clientMenuOptions_Label;
	//JTextField for the Client Options
	private JTextField clientMenuOptions_TextField;
	
	//javax.swing.Font for Client Menu Options
	private Font clientFont;
	private Font managerFont;
	//JLabels for the Manager Options
	private JLabel managerMenuOptions_Label;
	//JTextField for the Manager Options
	private JTextField managerMenuOptions_TextField;
	
	//JTextFields for login details
	private final JTextField Login_TextField;
	private final JTextField Username_TextField;
	private final JTextField Password_TextField;
	private String login_OptionNumber = "";
	private String client_OptionNumber = "";
	private String manager_OptionNumber = "";
	private String username_Text = "";
	private String password_Text = "";
	//------------------------------------------------------------
	
	//booleans for login and client menu
	private boolean login = false;
	private int login_Counter = 0;
	private boolean client_DisplayMenu = false;
	private boolean manager_DisplayMenu = false;
	private boolean client_WriteBooking = false;
	//------------------------------------------------------------
	
	//Login Details for Clients
	private String[][] client_LoginDetails = {{"John Smith", "1234"},{"Chester Shaw", "1234*"}};
	private String temp_ClientUsername = "";
	private String temp_ClientPassword = "";
	
	//Login Details for Managers
	private String[][] manager_LoginDetails = {{"JohnBossy", "BBBB"},{"ChesterDaBoss", "BBBB*"}};
	private String temp_ManagerUsername = "";
	private String temp_ManagerPassword = "";
	
	
	
	//JFrame for booking
	private JFrame booking_Frame;
	
	//Reads the class XMLApartmentsReader
	private XMLApartmentsReader apartments_Reader;
	//Reads the class XMLBookingReader
	private XMLBookingReader booking_Reader;
	//Reads the class XMLBookingReader
	private XMLConfirmationReader ConfirmationReader;
	
	//Strings for Apartment data
	private String[][] apartments_Data = new String[10][9];
	private String column[]={"Apartment ID", "Apartment Name", "Price per Night", "Start Date", "End Date", "Max Guests", "Number Beds", "Number Baths", "Living Room"};
	//Strings for Client data
	private String[][] clients_Data = new String[10][9];
	private String bookColumn[]={"Booking ID", "Apartment Name", "First Name", "Last Name", "Start Date", "End Date", "Max Guests I want", "Catering"};
	//Strings for Confirmation data
	private String[][] confirm_Data = new String[10][9];
	private String confirmColumn[]={"Booking ID", "First Name", "Last Name", "Max Guests I want", "Start Date", "End Date", "Apartment Name", "Number Beds", "Living Room", "Number Baths", "Catering"};
	
	//JPanel, JFrame and JScrollPane for display
	private JPanel display_Panel;
	private JFrame display_Frame;
	private JScrollPane display_ScrollPanel;
	
	//Document and reads the class XMLBookingWriter
	private Document write_Doc;
	private XMLBookingWriter booking_Writer;
	
	//Strings for client booking apartment details
	private String clientBooking_AptName = "";
	private String clientBooking_FirstName = "";
	private String clientBooking_LastName = "";
	private String clientBooking_MaxGuests = "";
	private String clientBooking_StartDate = "";
	private String clientBooking_EndDate = "";
	private String clientBooking_Catering = "";
	//------------------------------------------------------------
	
	//Files, Documents for XML
	//------------------------------------------------------------
	private File input_File;
	private DocumentBuilder dBuilder;
	private DocumentBuilderFactory dbFactory;
	private Document aBookingDoc;
	//------------------------------------------------------------
	
	//JButton for Booking
	//------------------------------------------------------------
	private JButton booking_Button;
	//------------------------------------------------------------
	//================================================================================================================================================================================
	
	//Constructor --> No-Argument
	public MyHotelManagement()
	{
		//LOGIN DETAILS
		//Creates Login layout for Chester's Hotel
		//------------------------------------------------------------------------------------------
		super("Chester's Hotel");
		FlowLayout1 = new FlowLayout();
		BorderLayout1 = new BorderLayout();
		BorderLayout1.setHgap(10);
		BorderLayout1.setVgap(10);
		FlowLayout2 = new FlowLayout();
		FlowLayout3 = new FlowLayout();
		BorderLayout2 = new BorderLayout();
		BorderLayout2_B = new BorderLayout();
		
		Login_Label = new JLabel("Login Options (1: Client, 2: Manager)");
		Login_TextField = new JTextField(50);
		Login_TextField.addActionListener(this);
		
		
		setLayout(FlowLayout1);
		
		Panel1 = new JPanel();
		Panel2 = new JPanel();
		Panel2_B = new JPanel();
		Panel3 = new JPanel();
		
		
		Panel1.setLayout(BorderLayout1);
		Panel1.setVisible(true);
		this.add(Panel1);
		Panel2.setLayout(BorderLayout2);
		Panel2.setVisible(true);
		Panel2_B.setLayout(BorderLayout2_B);
		Panel2_B.setVisible(true);
		Panel1.add(Panel2, BorderLayout.EAST);
		this.add(Panel1);
		Panel1.add(Panel2_B, BorderLayout.WEST);
		this.add(Panel1);
		
		Panel3.setLayout(FlowLayout3);
		Panel3.setVisible(true);
		Panel1.add(Panel3, BorderLayout.SOUTH);
		this.add(Panel1);
		//------------------------------------------------------------------------------------------
		
		//Login Details Label and TextFields
		//------------------------------------------------------------------------------------------
		Login_Label.setVisible(true);
		Panel2_B.add(Login_Label, BorderLayout.NORTH);
		Panel2_B.setVisible(true);
		Panel1.add(Panel2_B, BorderLayout.WEST);
		this.add(Panel1);
		
		Login_TextField.setSize(100, 100);
		Login_TextField.setVisible(true);
		Panel2.add(Login_TextField, BorderLayout.NORTH);
		Panel2.setVisible(true);
		Panel1.add(Panel2, BorderLayout.EAST);
		this.add(Panel1);
		//------------------------------------------------------------------------------------------
		
		//Username Label and TextFields
		//------------------------------------------------------------------------------------------
		Username_Label = new JLabel("Username: ");
		Username_TextField = new JTextField(50);
		Username_TextField.addActionListener(this);
		
		Username_Label.setVisible(true);
		Panel2_B.add(Username_Label, BorderLayout.CENTER);
		Panel2_B.setVisible(true);
		Panel1.add(Panel2_B, BorderLayout.WEST);
		this.add(Panel1);
		
		Username_TextField.setSize(100, 100);
		Username_TextField.setVisible(true);
		Panel2.add(Username_TextField, BorderLayout.CENTER);
		Panel2.setVisible(true);
		Panel1.add(Panel2, BorderLayout.EAST);
		this.add(Panel1);
		//------------------------------------------------------------------------------------------
		
		//Password Label and TextFields
		//------------------------------------------------------------------------------------------
		Password_Label = new JLabel("Password: ");
		Password_TextField = new JTextField(50);
		Password_TextField.addActionListener(this);
		
		Password_Label.setVisible(true);
		Panel2_B.add(Password_Label, BorderLayout.SOUTH);
		Panel2_B.setVisible(true);
		Panel1.add(Panel2_B, BorderLayout.WEST);
		this.add(Panel1);
		
		Password_TextField.setSize(100, 100);
		Password_TextField.setVisible(true);
		Panel2.add(Password_TextField, BorderLayout.SOUTH);
		Panel2.setVisible(true);
		Panel1.add(Panel2, BorderLayout.EAST);
		this.add(Panel1);
		//------------------------------------------------------------------------------------------
		//================================================================================================================================================================================
		
		
		//CLIENT DETAILS
		//Apartment Selection Label and TextField
		//------------------------------------------------------------------------------------------
		Apt_SelectionLabel = new JLabel("Apartment Name");
		Apt_SelectionTextField = new JTextField(15);
		Apt_SelectionTextField.addActionListener(this);
		//------------------------------------------------------------------------------------------
		
		//First Name Label and TextField
		//------------------------------------------------------------------------------------------
		Apt_FirstNameLabel = new JLabel("First Name");
		Apt_FirstNameTextField = new JTextField(15);
		Apt_FirstNameTextField.addActionListener(this);
		//------------------------------------------------------------------------------------------
		
		//Last Name Label and TextField
		//------------------------------------------------------------------------------------------
		Apt_LastNameLabel = new JLabel("Last Name");
		Apt_LastNameTextField = new JTextField(15);
		Apt_LastNameTextField.addActionListener(this);
		//------------------------------------------------------------------------------------------
		
		//Max Guests Label and TextField
		Apt_MaxGuestsLabel = new JLabel("Max Guests");
		Apt_MaxGuestsTextField = new JTextField(15);
		Apt_MaxGuestsTextField.addActionListener(this);
		//------------------------------------------------------------------------------------------
		
		//Start Date Label and TextField
		//------------------------------------------------------------------------------------------
		Apt_StartDateLabel = new JLabel("Start Date");
		Apt_StartDateTextField = new JTextField(15);
		Apt_StartDateTextField.addActionListener(this);
		//------------------------------------------------------------------------------------------
		
		//End Date Label and TextField
		//------------------------------------------------------------------------------------------
		Apt_EndDateLabel = new JLabel("End Date");
		Apt_EndDateTextField = new JTextField(15);
		Apt_EndDateTextField.addActionListener(this);
		//------------------------------------------------------------------------------------------
		
		//Catering Label and TextField
		//------------------------------------------------------------------------------------------
		Apt_CateringBookingLabel = new JLabel("Catering(Yes or No)");
		Apt_CateringBookingTextField = new JTextField(15);
		Apt_CateringBookingTextField.addActionListener(this);
		//------------------------------------------------------------------------------------------
		
		//Display Frame and Panel
		display_Frame = new JFrame();
		display_Panel = new JPanel();
		//================================================================================================================================================================================
	}
	
	
	//Constructor --> @Override Action
	public void actionPerformed(ActionEvent event)
	{
		
		login_OptionNumber = Login_TextField.getText();
		//Debugging statement
		System.out.println(login_OptionNumber);
		
		username_Text = Username_TextField.getText();
		//Debugging statement
		System.out.println(username_Text);
		
		password_Text = Password_TextField.getText();
		//Debugging statement
		System.out.println(password_Text);
		
		//While loop for Usernames and Passwords
		while (login == false)
		{
			//for loop for Usernames and Passwords
			for(int i = 0; i<2; i++)
			{
				//Temp Client login details
				temp_ClientUsername = client_LoginDetails[i][0];
				temp_ClientPassword = client_LoginDetails[i][1];
				
				//Temp Manager login details
				temp_ManagerUsername = manager_LoginDetails[i][0];
				temp_ManagerPassword = manager_LoginDetails[i][1];
				
				
				//Debugging statement
				System.out.println("Welcome: " + temp_ClientUsername);
				//LOGIN OPITION 1 ---> Client Login
				if ((new String(username_Text).equals(temp_ClientUsername)) & new String(password_Text).equals(temp_ClientPassword) & new String(login_OptionNumber).equals("1"))
				{
					System.out.println("Client Login Successful!");
					JOptionPane.showMessageDialog(null, "Client Login Successful");
					login = true;
					
					//CLIENT OPTIONS MENU --> Creates and displays Options Menu for Client
					//PANEL 3 --> Client Options Menu
					StringBuilder buff = new StringBuilder();
					buff.append("<html><table>");
					buff.append(String.format("<tr><td align='left'>%s</td>"+ "</tr>", "CLIENT OPTIONS"));
					buff.append(String.format("<tr><td align='left'>%s</td>"+ "</tr>", "1. Do Your Booking"));
					buff.append(String.format("<tr><td align='left'>%s</td>"+ "</tr>", "2. Manage Your Booking"));
					buff.append(String.format("<tr><td align='left'>%s</td>"+ "</tr>", "3. EXIT"));
					buff.append("</table></html>");
					
					//Client Options Menu Font
					clientFont = new Font("Arial", Font.ITALIC, 24);
					
					//Client Menu Options Label and TextFields
					//---------------------------------------------------------------------
					clientMenuOptions_Label = new  JLabel(buff.toString());
					clientMenuOptions_Label.setFont(clientFont);
					Panel3.add(clientMenuOptions_Label, BorderLayout.NORTH);
					Panel3.setVisible(true);
					Panel1.add(Panel3, BorderLayout.SOUTH);
					Panel1.revalidate();
					Panel1.repaint();
					this.add(Panel1);
					
					clientMenuOptions_TextField = new JTextField(50);
					clientMenuOptions_TextField.addActionListener(this);
					Panel3.add(clientMenuOptions_TextField, BorderLayout.SOUTH);
					Panel3.setVisible(true);
					Panel1.add(Panel3, BorderLayout.SOUTH);
					Panel1.revalidate();
					Panel1.repaint();
					this.add(Panel1);
					client_DisplayMenu = true;
					//---------------------------------------------------------------------	
				}//end if
				//LOGIN OPITION 2 ---> Manager Login
				else if ((new String (username_Text).equals(temp_ManagerUsername)) & new String (password_Text).equals(temp_ManagerPassword) & new String (login_OptionNumber).equals("2"))
				{
					System.out.println("Manager Login Successful");
					JOptionPane.showMessageDialog(null, "Manager Login Successful");
					login = true;
					login_Counter = 3;
					
					//MANAGER OPTIONS MENU --> Creates and displays Options Menu for Manager
					//PANEL 3 --> Manager Options Menu
					StringBuilder managerBuff = new StringBuilder();
					managerBuff.append("<html><table>");
					managerBuff.append(String.format("<tr><td align='left'>%s</td>"+ "</tr>", "MANAGER OPTIONS"));
					managerBuff.append(String.format("<tr><td align='left'>%s</td>"+ "</tr>", "1. View all Bookings"));
					managerBuff.append(String.format("<tr><td align='left'>%s</td>"+ "</tr>", "2. Manage a Booking"));
					managerBuff.append(String.format("<tr><td align='left'>%s</td>"+ "</tr>", "3. EXIT"));
					managerBuff.append("</table></html>");
					
					//Manager Options Menu Font
					managerFont = new Font("Arial", Font.ITALIC, 24);
					
					//Manager Menu Options Label and TextFields
					//---------------------------------------------------------------------
					managerMenuOptions_Label = new JLabel(managerBuff.toString());
					managerMenuOptions_Label.setFont(managerFont);
					Panel3.add(managerMenuOptions_Label, BorderLayout.NORTH);
					Panel3.setVisible(true);
					Panel1.add(Panel3, BorderLayout.SOUTH);
					Panel1.revalidate();
					Panel1.repaint();
					this.add(Panel1);
					
					managerMenuOptions_TextField = new JTextField(50);
					managerMenuOptions_TextField.addActionListener(this);
					Panel3.add(managerMenuOptions_TextField, BorderLayout.SOUTH);
					Panel3.setVisible(true);
					Panel1.add(Panel3, BorderLayout.SOUTH);
					Panel1.revalidate();
					Panel1.repaint();
					this.add(Panel1);
					//---------------------------------------------------------------------
				}//end else if
				else
				{ //If login = 0, then the login has failed
					if ((login_Counter==0) & (login==false))
					{
						login_Counter = login_Counter + 1;
						JOptionPane.showMessageDialog(this, "Login Failed!");
					}
				}//end else
			}//end for
		}//end while

		//CLIENT --> Do Booking Option
		if(client_DisplayMenu == true)
		{
			if (new String(clientMenuOptions_TextField.getText()).equals("1"))
			{
				//Debugging statement
				System.out.println("Want to make a booking?");
				
				//Gathers data from other classes
				apartments_Reader = new XMLApartmentsReader();
				booking_Writer = new XMLBookingWriter();
				
				//String [][] apartmentsReader()
				apartments_Data = apartments_Reader.apartmentsReader();
				
				
				
				//set up the new frame for the Booking
				booking_Frame = new JFrame("Do Booking");
				booking_Frame.setDefaultCloseOperation(JFrame.HIDE_ON_CLOSE);
				booking_Frame.setSize(1200, 500);
				booking_Frame.setVisible(true);
				
				//Creates and Displays Booking Options
				//---------------------------------------------------------------------
				FlowLayout_booking1 = new FlowLayout(); 
				BorderLayout_booking1 = new BorderLayout(); 
				BorderLayout_booking2 = new BorderLayout(); 
				BorderLayout_booking3 = new BorderLayout(); 
				FlowLayout_booking2 = new FlowLayout(); 

				//Creates Booking Layout
				booking_Frame.setLayout(FlowLayout_booking1);
				
				Panel_booking1 = new JPanel();
				Panel_booking3 = new JPanel();
				Panel_booking3A = new JPanel();
				Panel_booking3B = new JPanel();
				Panel_booking2 = new JPanel();
				
				Panel_booking1.setLayout(BorderLayout_booking1);
				booking_Frame.add(Panel_booking1);
				
				Panel_booking2.setLayout(BorderLayout_booking2);
				Panel_booking2.setVisible(true);
				Panel_booking1.add(Panel_booking2, BorderLayout.NORTH);
				booking_Frame.add(Panel_booking1);
				
				Panel_booking3.setLayout(FlowLayout_booking2);
				FlowLayout_booking2.setAlignment(FlowLayout.CENTER);
				Panel_booking3.setVisible(true);
				Panel_booking1.add(Panel_booking3, BorderLayout.SOUTH);
				booking_Frame.add(Panel_booking1);
				
				//Displays table for Apartments
				apartments_Reader.tableDisplay(apartments_Data, column, Panel_booking2, booking_Frame);
				
				//If true, allow booking to be written
				client_WriteBooking = true;
				//---------------------------------------------------------------------
			}//end if
		}//end if
		
		//Writes booking details if they are true
		if (client_WriteBooking == true)
		{
			//Apartment Selection
			//---------------------------------------------------------------//
			Apt_SelectionLabel.setVisible(true);
			Panel_booking3.add(Apt_SelectionLabel, BorderLayout.NORTH);
			Panel_booking3.setVisible(true);
			Panel_booking1.add(Panel_booking3, BorderLayout.NORTH);
			booking_Frame.add(Panel_booking1);
			
			Apt_SelectionTextField.setSize(15, 15);
			Apt_SelectionTextField.setVisible(true);
			Panel_booking3.add(Apt_SelectionTextField, BorderLayout.CENTER);
			Panel_booking3.setVisible(true);
			Panel_booking1.add(Panel_booking3, BorderLayout.NORTH);
			booking_Frame.add(Panel_booking1);
			//---------------------------------------------------------------//
			
			//First Name for booking Selection
			//---------------------------------------------------------------//
			Apt_FirstNameLabel.setVisible(true);
			Panel_booking3.add(Apt_FirstNameLabel);
			Panel_booking3.setVisible(true);
			Panel_booking1.add(Panel_booking3, BorderLayout.NORTH);
			booking_Frame.add(Panel_booking1);
			
			Apt_FirstNameTextField.setSize(20, 15);
			Apt_FirstNameTextField.setVisible(true);
			Panel_booking3.add(Apt_FirstNameTextField);
			Panel_booking3.setVisible(true);
			Panel_booking1.add(Panel_booking3, BorderLayout.NORTH);
			booking_Frame.add(Panel_booking1);
			//---------------------------------------------------------------//
			
			//Last Name for booking Selection
			//---------------------------------------------------------------//
			Apt_LastNameLabel.setVisible(true);
			Panel_booking3.add(Apt_LastNameLabel);
			Panel_booking3.setVisible(true);
			Panel_booking1.add(Panel_booking3, BorderLayout.NORTH);
			booking_Frame.add(Panel_booking1);
			
			Apt_LastNameTextField.setSize(15, 15);
			Apt_LastNameTextField.setVisible(true);
			Panel_booking3.add(Apt_LastNameTextField);
			Panel_booking3.setVisible(true);
			Panel_booking1.add(Panel_booking3, BorderLayout.NORTH);
			booking_Frame.add(Panel_booking1);
			//---------------------------------------------------------------//
			
			//Max Guests for booking Selection
			//---------------------------------------------------------------//
			Apt_MaxGuestsLabel.setVisible(true);
			Panel_booking3.add(Apt_MaxGuestsLabel);
			Panel_booking3.setVisible(true);
			Panel_booking1.add(Panel_booking3, BorderLayout.NORTH);
			booking_Frame.add(Panel_booking1);
			
			Apt_MaxGuestsTextField.setSize(15, 15);
			Apt_MaxGuestsTextField.setVisible(true);
			Panel_booking3.add(Apt_MaxGuestsTextField);
			Panel_booking3.setVisible(true);
			Panel_booking1.add(Panel_booking3, BorderLayout.NORTH);
			booking_Frame.add(Panel_booking1);
			//---------------------------------------------------------------//
			
			//Start Date for booking Selection
			//---------------------------------------------------------------//
			Apt_StartDateLabel.setVisible(true);
			Panel_booking3.add(Apt_StartDateLabel);
			Panel_booking3.setVisible(true);
			Panel_booking1.add(Panel_booking3, BorderLayout.NORTH);
			booking_Frame.add(Panel_booking1);
			
			Apt_StartDateTextField.setSize(15, 15);
			Apt_StartDateTextField.setVisible(true);
			Panel_booking3.add(Apt_StartDateTextField);
			Panel_booking3.setVisible(true);
			Panel_booking1.add(Panel_booking3, BorderLayout.NORTH);
			booking_Frame.add(Panel_booking1);
			//---------------------------------------------------------------//
			
			//End Date for booking Selection
			//---------------------------------------------------------------//
			Apt_EndDateLabel.setVisible(true);
			Panel_booking3.add(Apt_EndDateLabel);
			Panel_booking3.setVisible(true);
			Panel_booking1.add(Panel_booking3, BorderLayout.NORTH);
			booking_Frame.add(Panel_booking1);
			
			Apt_EndDateTextField.setSize(20, 15);
			Apt_EndDateTextField.setVisible(true);
			Panel_booking3.add(Apt_EndDateTextField);
			Panel_booking3.setVisible(true);
			Panel_booking1.add(Panel_booking3, BorderLayout.NORTH);
			booking_Frame.add(Panel_booking1);
			//---------------------------------------------------------------//
			
			//Catering option for booking Selection
			//---------------------------------------------------------------//
			Apt_CateringBookingLabel.setVisible(true);
			Panel_booking3.add(Apt_CateringBookingLabel);
			Panel_booking3.setVisible(true);
			Panel_booking1.add(Panel_booking3, BorderLayout.NORTH);
			booking_Frame.add(Panel_booking1);
			
			Apt_CateringBookingTextField.setSize(15, 15);
			Apt_CateringBookingTextField.setVisible(true);
			Panel_booking3.add(Apt_CateringBookingTextField);
			Panel_booking3.setVisible(true);
			Panel_booking1.add(Panel_booking3, BorderLayout.NORTH);
			booking_Frame.add(Panel_booking1);
			//---------------------------------------------------------------//
			
			//Booking button for booking selection
			booking_Button = new JButton("Booking");
			booking_Button.addActionListener(this);
			booking_Button.setActionCommand("booking");
			booking_Button.setVisible(true);
			Panel_booking3.add(booking_Button);
			Panel_booking3.setVisible(true);
			Panel_booking1.add(Panel_booking3, BorderLayout.NORTH);
			booking_Frame.add(Panel_booking1);
			//---------------------------------------------------------------------
			
			//Writes booking details into ClientDetails.xml file.
			if("booking".equals(event.getActionCommand()))
			{
				clientBooking_AptName = Apt_SelectionTextField.getText();
				clientBooking_FirstName = Apt_FirstNameTextField.getText();
				clientBooking_LastName = Apt_LastNameTextField.getText();
				clientBooking_MaxGuests = Apt_MaxGuestsTextField.getText();
				clientBooking_StartDate = Apt_StartDateTextField.getText();
				clientBooking_EndDate = Apt_EndDateTextField.getText();
				clientBooking_Catering = Apt_CateringBookingTextField.getText();
				
				write_Doc = booking_Writer.serverConnection();
				//bookingWriter(Document doc, String filenameToWrite, String clientFirstName, String clientLastName, String maxGuests,
				//String bookingStartDate, String bookingEndDate, String bookingCatering)
				booking_Writer.bookingWriter(write_Doc, "D:\\Program Files\\eclipse\\workspace\\Element011\\src\\ClientDetails.xml",
						clientBooking_AptName, clientBooking_FirstName, clientBooking_LastName, clientBooking_StartDate, clientBooking_EndDate, clientBooking_MaxGuests, clientBooking_Catering);
			}//end if	
		}//end if
		
		//CLIENT --> Manage a Booking
		if(client_DisplayMenu == true)
		{
			if (new String(clientMenuOptions_TextField.getText()).equals("2"))
			{
				//Debugging statement
				System.out.println("Manage a booking?");
				
				//Gathers data from other classes
				booking_Reader = new XMLBookingReader();
				booking_Writer = new XMLBookingWriter();
				
				//String [][] apartmentsReader()
				clients_Data = booking_Reader.bookingReader();
						
				//set up the new frame for the Booking
				booking_Frame = new JFrame("Manage Booking");
				booking_Frame.setDefaultCloseOperation(JFrame.HIDE_ON_CLOSE);
				booking_Frame.setSize(1200, 500);
				booking_Frame.setVisible(true);
				
				//Creates and Displays Booking Options
				//---------------------------------------------------------------------
				FlowLayout_booking1 = new FlowLayout();
				BorderLayout_booking1 = new BorderLayout(); 
				BorderLayout_booking2 = new BorderLayout();
				BorderLayout_booking3 = new BorderLayout(); 
				FlowLayout_booking2 = new FlowLayout();

				
				//Creates Booking Layout
				booking_Frame.setLayout(FlowLayout_booking1);
				
				Panel_booking1 = new JPanel();
				Panel_booking3 = new JPanel();
				Panel_booking3A = new JPanel();
				Panel_booking3B = new JPanel();
				Panel_booking2 = new JPanel();
				
				Panel_booking1.setLayout(BorderLayout_booking1);
				booking_Frame.add(Panel_booking1);
				
				Panel_booking2.setLayout(BorderLayout_booking2);
				Panel_booking2.setVisible(true);
				Panel_booking1.add(Panel_booking2, BorderLayout.NORTH);
				booking_Frame.add(Panel_booking1);
				
				Panel_booking3.setLayout(FlowLayout_booking2);
				FlowLayout_booking2.setAlignment(FlowLayout.CENTER);
				Panel_booking3.setVisible(true);
				Panel_booking1.add(Panel_booking3, BorderLayout.SOUTH);
				booking_Frame.add(Panel_booking1);
				
				//Displays table for Booking
				booking_Reader.tableDisplay(clients_Data, bookColumn, Panel_booking2, booking_Frame);
				
				//If true, allow booking to be written
				client_WriteBooking = true;
				//---------------------------------------------------------------------
			}//end if
		}//end if
		
		//Writes booking details if they are true
		if (client_WriteBooking == true)
		{
			//Writes booking details into ClientDetails.xml file.
			if("booking".equals(event.getActionCommand()))
			{
				clientBooking_AptName = Apt_SelectionTextField.getText();
				clientBooking_FirstName = Apt_FirstNameTextField.getText();
				clientBooking_LastName = Apt_LastNameTextField.getText();
				clientBooking_MaxGuests = Apt_MaxGuestsTextField.getText();
				clientBooking_StartDate = Apt_StartDateTextField.getText();
				clientBooking_EndDate = Apt_EndDateTextField.getText();
				clientBooking_Catering = Apt_CateringBookingTextField.getText();
				
				write_Doc = booking_Writer.serverConnection();
				//bookingWriter(Document doc, String filenameToWrite, String clientFirstName, String clientLastName, String maxGuests,
				//String bookingStartDate, String bookingEndDate, String bookingCatering)
				booking_Writer.bookingWriter(write_Doc, "D:\\Program Files\\eclipse\\workspace\\Element011\\src\\ClientDetails.xml",
						clientBooking_AptName, clientBooking_FirstName, clientBooking_LastName, clientBooking_StartDate, clientBooking_EndDate, clientBooking_MaxGuests, clientBooking_Catering);
			}//end if	
		}//end if
	}//end method
}//end class
