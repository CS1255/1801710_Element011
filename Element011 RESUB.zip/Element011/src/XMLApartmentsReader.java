/*************************************************************************/
//* Name: SID: 1801710                                                  *//
//* Task: Element 010 - Hotel Management System                         *//
//* Description: XML Apartments Reader                                  *//
//* Date: 17/05/2020                                                    *//
//*                                                                     *//
/************************************************************************/

//import packages
import java.io.File;
import javax.xml.parsers.DocumentBuilderFactory;
import javax.xml.parsers.DocumentBuilder;
import javax.swing.*;
import java.awt.*;
import org.w3c.dom.Document;
import org.w3c.dom.NodeList;
import org.w3c.dom.Node;
import org.w3c.dom.Element;

//start class
//Extends XMLReader as it is part of the XMLApartmentsReader class
public class XMLApartmentsReader extends XMLReader 
{
	//Document for Apartments Reader
	//------------------------------------------------------------
	private Document apart_Doc;
	//------------------------------------------------------------
	
	//String for Apartments Reader
	//------------------------------------------------------------
	private String[][] apart_Data = new String[10][9];
	//------------------------------------------------------------
	
	//Integers for Apartments Reader
	//------------------------------------------------------------
	private int row_Counter = 0;
	private int column_Counter = 0;
	//------------------------------------------------------------
	
	//JTable and ScrollPane for Apartments Reader
	private JTable apartments_Table;
	private JScrollPane display_ScrollPanel;
	//------------------------------------------------------------
	//================================================================================================================================================================================
	
	//Constructor --> apartmentsReader STRING
	public String[][] apartmentsReader()
	{	
		//Gathers information from Apartments.xml file, becomes a NodeList.
		apart_Doc = serverConnection("D:\\Program Files\\eclipse\\workspace\\Element011\\src\\Apartments.xml");
		System.out.println("Root element :" + apart_Doc.getDocumentElement().getNodeName());
		NodeList nList = apart_Doc.getElementsByTagName("apartment");
		System.out.println("----------------------------");
		
		//for loop for apartments data
		for (int temp = 0; temp < nList.getLength(); temp++)
		{
			//Node for NodeList
			Node nNode = nList.item(temp);
			System.out.println("\nCurrent Element :" + nNode.getNodeName());
			
			//Node gets attributes, text content from XML file
			if (nNode.getNodeType() == Node.ELEMENT_NODE)
			{
				Element eElement = (Element) nNode;
				String aptID_Table = eElement.getAttribute("ID");
				String aptName_Table = eElement.getElementsByTagName("apartmentname").item(0).getTextContent();
				String price_Table = eElement.getElementsByTagName("price").item(0).getTextContent();
				String startDate_Table = eElement.getElementsByTagName("startdate").item(0).getTextContent();
				String endDate_Table = eElement.getElementsByTagName("enddate").item(0).getTextContent();
				String maxGuests_Table = eElement.getElementsByTagName("maxguests").item(0).getTextContent();
				String numBeds_Table = eElement.getElementsByTagName("numberbeds").item(0).getTextContent();
				String numBaths_Table = eElement.getElementsByTagName("numberbaths").item(0).getTextContent();
				String livingRoom_Table = eElement.getElementsByTagName("livingroom").item(0).getTextContent();
				
				//Data and Column counters for aptID_Table
				apart_Data[row_Counter][column_Counter] = aptID_Table;
				column_Counter = column_Counter + 1;
				
				//Data and Column counters for aptName_Table
				apart_Data[row_Counter][column_Counter] = aptName_Table;
				column_Counter = column_Counter + 1;
				
				//Data and Column counters for price_Table
				apart_Data[row_Counter][column_Counter] = price_Table;
				column_Counter = column_Counter + 1;
				
				//Data and Column counters for startDate_Table
				apart_Data[row_Counter][column_Counter] = startDate_Table;
				column_Counter = column_Counter + 1;
				
				//Data and Column counters for endDate_Table
				apart_Data[row_Counter][column_Counter] = endDate_Table;
				column_Counter = column_Counter + 1;
				
				//Data and Column counters for maxGuests_Table
				apart_Data[row_Counter][column_Counter] = maxGuests_Table;
				column_Counter = column_Counter + 1;
				
				//Data and Column counters for numBeds_Table
				apart_Data[row_Counter][column_Counter] = numBeds_Table;
				column_Counter = column_Counter + 1;
				
				//Data and Column counters for numBaths_Table
				apart_Data[row_Counter][column_Counter] = numBaths_Table;
				column_Counter = column_Counter + 1;
				
				//Data counters for livingRoom_Table
				apart_Data[row_Counter][column_Counter] = livingRoom_Table;
				
				
				//Debugging statements
				System.out.println("Apartment ID: " + aptID_Table);
				System.out.println("Price per Night: " + price_Table);
				System.out.println("Start Date: " + startDate_Table);
				System.out.println("End Date: " + endDate_Table);
				System.out.println("Max number of guests: " + maxGuests_Table);
				System.out.println("Number of Bedrooms: " + numBeds_Table);
				System.out.println("Number of Bathrooms: " + numBaths_Table);
				System.out.println("Separate Living Room: " + livingRoom_Table);			
			}// end if
			
			//Add 1 to counter
			row_Counter = row_Counter + 1;
			column_Counter = 0;
		}// end for
		//Returns apartment data
		return apart_Data;
	}//end method
	
	//Displays apartments table
	public void tableDisplay(String[][] dataTable, String columnTable[], JPanel displayPanel, JFrame displayFrame)
	{
			//Creates table for apartments
			apartments_Table = new JTable(dataTable,columnTable);
			apartments_Table.setBounds(30,40,1200,200);
			display_ScrollPanel = new JScrollPane(apartments_Table);
			
			displayPanel.add(display_ScrollPanel);		
			displayFrame.add(displayPanel);
			displayFrame.setVisible(true);
	}//end method
}//end class
