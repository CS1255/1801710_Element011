/*************************************************************************/
//* Name: SID: 1801710                                                  *//
//* Task: Element 010 - Hotel Management System                         *//
//* Description: Hotel Management Application                           *//
//* Date: 17/05/2020                                                    *//
//*                                                                     *//
/************************************************************************/

//import java packages
import javax.swing.JFrame;

//start class
public class MyHotelManagementApp 
{
	//Declares and initialises Class 
	private static MyHotelManagement HMS;
		//Method Main
		public static void main(String[] args)
			{
				//Reads MyHotelManagement code
				HMS = new MyHotelManagement();
				HMS.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
				HMS.setSize(1200, 400);
				HMS.setVisible(true);
			}	
}//end class
