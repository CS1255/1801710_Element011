/*************************************************************************/
//* Name: SID: 1801710                                                  *//
//* Task: Element 010 - Hotel Management System                         *//
//* Description: XML Booking Reader                                     *//
//* Date: 17/05/2020                                                    *//
//*                                                                     *//
/************************************************************************/

//import packages
import java.io.File;
import javax.xml.parsers.DocumentBuilderFactory;
import javax.xml.parsers.DocumentBuilder;
import javax.swing.*;
import java.awt.*;
import org.w3c.dom.Document;
import org.w3c.dom.NodeList;
import org.w3c.dom.Node;
import org.w3c.dom.Element;

//start class
//Extends XMLReader as it is part of the XMLBookingReader class
public class XMLBookingReader extends XMLReader
{
	//Document for Bookings Reader
	//------------------------------------------------------------
	private Document client_Doc;
	//------------------------------------------------------------
	
	//String for Bookings Reader
	//------------------------------------------------------------
	private String[][] client_Data = new String[10][9];
	//------------------------------------------------------------
	
	//Integers for Bookings Reader
	//------------------------------------------------------------
	private int row_Counter = 0;
	private int column_Counter = 0;
	//------------------------------------------------------------
	
	//JTable and ScrollPane for Bookings Reader
	//------------------------------------------------------------
	private JTable client_Table;
	private JScrollPane display_ScrollPanel;
	//------------------------------------------------------------
	//================================================================================================================================================================================
	
	//Constructor --> bookingReader STRING
	public String[][] bookingReader()
	{		
		//Gathers information from ClientDetails.xml file, becomes a NodeList.
		client_Doc = serverConnection("D:\\Program Files\\eclipse\\workspace\\Element011\\src\\ClientDetails.xml");
		System.out.println("Root element :" + client_Doc.getDocumentElement().getNodeName());
		NodeList nList = client_Doc.getElementsByTagName("clientbooking");
		System.out.println("----------------------------");
		
		//for loop for client data
		for (int temp = 0; temp < nList.getLength(); temp++)
		{
			//Node for NodeList
			Node nNode = nList.item(temp);
			System.out.println("\nCurrent Element :" + nNode.getNodeName());
			
			//Node gets attributes, text content from XML file
			if (nNode.getNodeType() == Node.ELEMENT_NODE)
			{
				Element eElement = (Element) nNode;
				String bookID_Table = eElement.getAttribute("ID");
				String aptName_Table = eElement.getElementsByTagName("apartmentname").item(0).getTextContent();
				String firstName_Table = eElement.getElementsByTagName("firstname").item(0).getTextContent();
				String lastName_Table = eElement.getElementsByTagName("lastname").item(0).getTextContent();
				String numGuests_Table = eElement.getElementsByTagName("numberguests").item(0).getTextContent();
				String startDate_Table = eElement.getElementsByTagName("startdate").item(0).getTextContent();
				String endDate_Table = eElement.getElementsByTagName("enddate").item(0).getTextContent();
				String catering_Table = eElement.getElementsByTagName("catering").item(0).getTextContent();
				
				//Data and Column counters for bookID_Table
				client_Data [row_Counter][column_Counter] = bookID_Table;
				column_Counter = column_Counter + 1;
				
				//Data and Column counters for aptName_Table
				client_Data [row_Counter][column_Counter] = aptName_Table;
				column_Counter = column_Counter + 1;
				
				//Data and Column counters for firstName_Table
				client_Data [row_Counter][column_Counter] = firstName_Table;
				column_Counter = column_Counter + 1;
				
				//Data and Column counters for lastName_Table
				client_Data [row_Counter][column_Counter] = lastName_Table;
				column_Counter = column_Counter + 1;
				
				//Data and Column counters for numGuests_Table
				client_Data [row_Counter][column_Counter] = numGuests_Table;
				column_Counter = column_Counter + 1;
				
				//Data and Column counters for startDate_Table
				client_Data [row_Counter][column_Counter] = startDate_Table;
				column_Counter = column_Counter + 1;
				
				//Data and Column counters for endDate_Table
				client_Data [row_Counter][column_Counter] = endDate_Table;
				column_Counter = column_Counter + 1;
				
				//Data counters for catering_Table
				client_Data [row_Counter][column_Counter] = catering_Table;
						
				//Debugging statements
				System.out.println("Booking ID: " + bookID_Table);
				System.out.println("First Name: " + firstName_Table);
				System.out.println("Last Name: " + lastName_Table);
				System.out.println("Start Date: " + startDate_Table);
				System.out.println("End Date: " + endDate_Table);
				System.out.println("Max Guests I want: " + numGuests_Table);
				System.out.println("Catering: " + catering_Table);			
			}// end if
			
			//Add 1 to counter
			row_Counter = row_Counter + 1;
			column_Counter = 0;
		}// end for
		//Returns client data
		return client_Data;
	}//end method
	
	//Displays client table
	public void tableDisplay(String[][] dataTable, String columnTable[], JPanel displayPanel, JFrame displayFrame)
	{
			//Creates table for client
			client_Table = new JTable(dataTable,columnTable);
			client_Table.setBounds(30,40,1200,200);
			display_ScrollPanel = new JScrollPane(client_Table);
			
			displayPanel.add(display_ScrollPanel);
			displayFrame.add(displayPanel);
			displayFrame.setVisible(true);
	}//end method	
}//end class

