/*************************************************************************/
//* Name: SID: 1801710                                                  *//
//* Task: Element 010 - Hotel Management System                         *//
//* Description: XML Confirmation Reader                                *//
//* Date: 17/05/2020                                                    *//
//*                                                                     *//
/************************************************************************/

//import packages
import java.io.File;
import javax.xml.parsers.DocumentBuilderFactory;
import javax.xml.parsers.DocumentBuilder;
import org.w3c.dom.Document;
import org.w3c.dom.NodeList;
import org.w3c.dom.Node;
import org.w3c.dom.Element;
import javax.swing.*;
import java.awt.*;

//start class
//Extends XMLReader as it is part of the XMLConfirmationReader class
public class XMLConfirmationReader extends XMLReader
{
	//Document for Confirmation Reader
	//------------------------------------------------------------
	private Document confirm_Doc;
	//------------------------------------------------------------
	
	//String for Confirmation Reader
	private String[][] confirm_Data = new String[10][9];
	//------------------------------------------------------------
	
	//Integers for Confirmation Reader
	//------------------------------------------------------------
	private int row_Counter = 0;
	private int column_Counter = 0;
	//------------------------------------------------------------
	
	//JTable and ScrollPane for Confirmation Reader
	//------------------------------------------------------------
	private JTable confirmation_Table;
	private JScrollPane display_ScrollPanel;
	//------------------------------------------------------------
	//================================================================================================================================================================================	
	
	//Constructor --> confirmationReader STRING
	public String[][] confirmationReader()
	{	
		//Gathers information from ConfirmationDetails.xml file, becomes a NodeList.
		confirm_Doc = serverConnection("D:\\Program Files\\eclipse\\workspace\\Element011\\src\\ConfirmationDetails.xml");
		System.out.println("Root element :" + confirm_Doc.getDocumentElement().getNodeName());
		NodeList nList = confirm_Doc.getElementsByTagName("confirmbooking");
		System.out.println("----------------------------");
		
		//for loop for confirmation data
		for (int temp = 0; temp < nList.getLength(); temp++)
		{
			//Node for NodeList
			Node nNode = nList.item(temp);
			System.out.println("\nCurrent Element :" + nNode.getNodeName());
			
			//Node gets attributes, text content from XML file
			if (nNode.getNodeType() == Node.ELEMENT_NODE)
			{
				Element eElement = (Element) nNode;
				String bookID_Table = eElement.getAttribute("ID");
				String firstName_Table = eElement.getElementsByTagName("firstname").item(0).getTextContent();
				String lastName_Table = eElement.getElementsByTagName("lastname").item(0).getTextContent();
				String numGuests_Table = eElement.getElementsByTagName("numberguests").item(0).getTextContent();
				String startDate_Table = eElement.getElementsByTagName("startdate").item(0).getTextContent();
				String endDate_Table = eElement.getElementsByTagName("enddate").item(0).getTextContent();
				String aptName_Table = eElement.getElementsByTagName("apartmentname").item(0).getTextContent();
				String numBeds_Table = eElement.getElementsByTagName("numberbeds").item(0).getTextContent();
				String livingRoom_Table = eElement.getElementsByTagName("livingroom").item(0).getTextContent();
				String numBaths_Table = eElement.getElementsByTagName("numberbaths").item(0).getTextContent();
				String catering_Table = eElement.getElementsByTagName("catering").item(0).getTextContent();
				
				//Data and Column counters for bookID_Table
				confirm_Data[row_Counter][column_Counter] = bookID_Table;
				column_Counter = column_Counter + 1;
				
				//Data and Column counters for firstName_Table
				confirm_Data[row_Counter][column_Counter] = firstName_Table;
				column_Counter = column_Counter + 1;
				
				//Data and Column counters for lastName_Table
				confirm_Data[row_Counter][column_Counter] = lastName_Table;
				column_Counter = column_Counter + 1;
				
				//Data and Column counters for numGuests_Table
				confirm_Data[row_Counter][column_Counter] = numGuests_Table;
				column_Counter = column_Counter + 1;
				
				//Data and Column counters for startDate_Table
				confirm_Data[row_Counter][column_Counter] = startDate_Table;
				column_Counter = column_Counter + 1;
				
				//Data and Column counters for endDate_Table
				confirm_Data[row_Counter][column_Counter] = endDate_Table;
				column_Counter = column_Counter + 1;
				
				//Data and Column counters for aptName_Table
				confirm_Data[row_Counter][column_Counter] = aptName_Table;
				column_Counter = column_Counter + 1;
				
				//Data and Column counters for numBeds_Table
				confirm_Data[row_Counter][column_Counter] = numBeds_Table;
				column_Counter = column_Counter + 1;
				
				//Data and Column counters for livingRoom_Table
				confirm_Data[row_Counter][column_Counter] = livingRoom_Table;
				column_Counter = column_Counter + 1;
				
				//Data and Column counters for numBaths_Table
				confirm_Data[row_Counter][column_Counter] = numBaths_Table;
				column_Counter = column_Counter + 1;
				
				//Data counters for catering_Table
				confirm_Data[row_Counter][column_Counter] = catering_Table;
						
				//Debugging statements
				System.out.println("Booking ID: " + bookID_Table);
				System.out.println("First Name: " + firstName_Table);
				System.out.println("Last Name: " + lastName_Table);
				System.out.println("Max Guests I want: " + numGuests_Table);
				System.out.println("Start Date: " + startDate_Table);
				System.out.println("End Date: " + endDate_Table);
				System.out.println("Apartment Name: " + aptName_Table);
				System.out.println("Number of Bedrooms: " + numBeds_Table);
				System.out.println("Separate Living Room: " + livingRoom_Table);
				System.out.println("Number of Bathrooms: " + numBaths_Table);
				System.out.println("Catering: " + catering_Table);			
			}// end if
			
			//Add 1 to counter
			row_Counter = row_Counter + 1;
			column_Counter = 0;
		}// end for
		//Returns confirmation data
		return confirm_Data;
	}//end method
	
	//Displays confirmation table
	public void tableDisplay(String[][] dataTable, String columnTable[], JPanel displayPanel, JFrame displayFrame)
	{
			//Creates table for confirmation
			confirmation_Table = new JTable(dataTable,columnTable);
			confirmation_Table.setBounds(30,40,1200,200);
			display_ScrollPanel = new JScrollPane(confirmation_Table);
			
			displayPanel.add(display_ScrollPanel);
			displayFrame.add(displayPanel);
			displayFrame.setVisible(true);
	}//end method
}//end class

