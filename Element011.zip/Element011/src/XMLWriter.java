/*************************************************************************/
//* Name: SID: 1801710                                                  *//
//* Task: Element 010 - Hotel Management System                         *//
//* Description: XML Writer			                                    *//
//* Date: 17/05/2020                                                    *//
//*                                                                     *//
/************************************************************************/

//import packages
import javax.xml.parsers.DocumentBuilderFactory;
import javax.xml.parsers.DocumentBuilder;
import javax.xml.transform.Transformer;
import javax.xml.transform.TransformerFactory;
import javax.xml.transform.dom.DOMSource;
import javax.xml.transform.stream.StreamResult;
import org.w3c.dom.Attr;
import org.w3c.dom.Document;
import org.w3c.dom.Element;
import java.io.File;

//start class
public class XMLWriter 
{
	//Documents for Writer
	//------------------------------------------------------------------------------------------
	private DocumentBuilderFactory dbFactory;
	private DocumentBuilder dBuilder;
	private Document doc;
	//------------------------------------------------------------------------------------------
	
	//Constructor --> serverConnection
	public Document serverConnection()
	{
		//try for building Writer
		try
		{
			//Creates the three layers used for XMLWriter
			dbFactory = DocumentBuilderFactory.newInstance();
			dBuilder = dbFactory.newDocumentBuilder();
			doc = dBuilder.newDocument();
		}
		catch (Exception e)
		{
			e.printStackTrace();
		}//end try...catch
		//Returns document
		return doc;	
	}//end method	
}//end class

