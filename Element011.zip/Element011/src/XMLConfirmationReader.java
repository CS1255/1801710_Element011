/*************************************************************************/
//* Name: SID: 1801710                                                  *//
//* Task: Element 010 - Hotel Management System                         *//
//* Description: XML Confirmation Reader                                *//
//* Date: 17/05/2020                                                    *//
//*                                                                     *//
/************************************************************************/

//import packages
import java.io.File;
import javax.xml.parsers.DocumentBuilderFactory;
import javax.xml.parsers.DocumentBuilder;
import org.w3c.dom.Document;
import org.w3c.dom.NodeList;
import org.w3c.dom.Node;
import org.w3c.dom.Element;
import javax.swing.*;
import java.awt.*;

//start class
//Extends XMLReader as it is part of the XMLConfirmationReader class
public class XMLConfirmationReader extends XMLReader
{
	//Document for Confirmation Reader
	//------------------------------------------------------------
	private Document aDoc;
	//------------------------------------------------------------
	
	//String for Confirmation Reader
	private String[][] data = new String[10][9];
	//------------------------------------------------------------
	
	//Integers for Confirmation Reader
	//------------------------------------------------------------
	private int rowCounter = 0;
	private int columnCounter = 0;
	//------------------------------------------------------------
	
	//JTable and ScrollPane for Confirmation Reader
	//------------------------------------------------------------
	private JTable confirmationTable;
	private JScrollPane displayScrollPanel;
	//------------------------------------------------------------
	//================================================================================================================================================================================	
	
	//Constructor --> confirmationReader STRING
	public String[][] confirmationReader()
	{	
		//Gathers information from ConfirmationDetails.xml file, becomes a NodeList.
		aDoc = serverConnection("D:\\Program Files\\eclipse\\workspace\\Element011\\src\\ConfirmationDetails.xml");
		System.out.println("Root element :" + aDoc.getDocumentElement().getNodeName());
		NodeList nList = aDoc.getElementsByTagName("confirmbooking");
		System.out.println("----------------------------");
		
		//for loop for confirmation data
		for (int temp = 0; temp < nList.getLength(); temp++)
		{
			//Node for NodeList
			Node nNode = nList.item(temp);
			System.out.println("\nCurrent Element :" + nNode.getNodeName());
			
			//Node gets attributes, text content from XML file
			if (nNode.getNodeType() == Node.ELEMENT_NODE)
			{
				Element eElement = (Element) nNode;
				String bookID_Table = eElement.getAttribute("ID");
				String firstName_Table = eElement.getElementsByTagName("firstname").item(0).getTextContent();
				String lastName_Table = eElement.getElementsByTagName("lastname").item(0).getTextContent();
				String numGuests_Table = eElement.getElementsByTagName("numberguests").item(0).getTextContent();
				String startDate_Table = eElement.getElementsByTagName("startdate").item(0).getTextContent();
				String endDate_Table = eElement.getElementsByTagName("enddate").item(0).getTextContent();
				String aptName_Table = eElement.getElementsByTagName("apartmentname").item(0).getTextContent();
				String numBeds_Table = eElement.getElementsByTagName("numberbeds").item(0).getTextContent();
				String livingRoom_Table = eElement.getElementsByTagName("livingroom").item(0).getTextContent();
				String numBaths_Table = eElement.getElementsByTagName("numberbaths").item(0).getTextContent();
				String catering_Table = eElement.getElementsByTagName("catering").item(0).getTextContent();
				
				//Data and Column counters for bookID_Table
				data[rowCounter][columnCounter] = bookID_Table;
				columnCounter = columnCounter + 1;
				
				//Data and Column counters for firstName_Table
				data[rowCounter][columnCounter] = firstName_Table;
				columnCounter = columnCounter + 1;
				
				//Data and Column counters for lastName_Table
				data[rowCounter][columnCounter] = lastName_Table;
				columnCounter = columnCounter + 1;
				
				//Data and Column counters for numGuests_Table
				data[rowCounter][columnCounter] = numGuests_Table;
				columnCounter = columnCounter + 1;
				
				//Data and Column counters for startDate_Table
				data[rowCounter][columnCounter] = startDate_Table;
				columnCounter = columnCounter + 1;
				
				//Data and Column counters for endDate_Table
				data[rowCounter][columnCounter] = endDate_Table;
				columnCounter = columnCounter + 1;
				
				//Data and Column counters for aptName_Table
				data[rowCounter][columnCounter] = aptName_Table;
				columnCounter = columnCounter + 1;
				
				//Data and Column counters for numBeds_Table
				data[rowCounter][columnCounter] = numBeds_Table;
				columnCounter = columnCounter + 1;
				
				//Data and Column counters for livingRoom_Table
				data[rowCounter][columnCounter] = livingRoom_Table;
				columnCounter = columnCounter + 1;
				
				//Data and Column counters for numBaths_Table
				data[rowCounter][columnCounter] = numBaths_Table;
				columnCounter = columnCounter + 1;
				
				//Data counters for catering_Table
				data[rowCounter][columnCounter] = catering_Table;
						
				//Debugging statements
				System.out.println("Booking ID: " + bookID_Table);
				System.out.println("First Name: " + firstName_Table);
				System.out.println("Last Name: " + lastName_Table);
				System.out.println("Max Guests I want: " + numGuests_Table);
				System.out.println("Start Date: " + startDate_Table);
				System.out.println("End Date: " + endDate_Table);
				System.out.println("Apartment Name: " + aptName_Table);
				System.out.println("Number of Bedrooms: " + numBeds_Table);
				System.out.println("Separate Living Room: " + livingRoom_Table);
				System.out.println("Number of Bathrooms: " + numBaths_Table);
				System.out.println("Catering: " + catering_Table);			
			}// end if
			
			//Add 1 to counter
			rowCounter = rowCounter + 1;
			columnCounter = 0;
		}// end for
		//Returns confirmation data
		return data;
	}//end method
	
	//Displays confirmation table
	public void tableDisplay(String[][] dataTable, String columnTable[], JPanel displayPanel, JFrame displayFrame)
	{
			//Creates table for confirmation
			confirmationTable = new JTable(dataTable,columnTable);
			confirmationTable.setBounds(30,40,1200,200);
			displayScrollPanel = new JScrollPane(confirmationTable);
			
			displayPanel.add(displayScrollPanel);
			displayFrame.add(displayPanel);
			displayFrame.setVisible(true);
	}//end method
}//end class

