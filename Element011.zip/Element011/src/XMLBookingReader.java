/*************************************************************************/
//* Name: SID: 1801710                                                  *//
//* Task: Element 010 - Hotel Management System                         *//
//* Description: XML Booking Reader                                     *//
//* Date: 17/05/2020                                                    *//
//*                                                                     *//
/************************************************************************/

//import packages
import java.io.File;
import javax.xml.parsers.DocumentBuilderFactory;
import javax.xml.parsers.DocumentBuilder;
import javax.swing.*;
import java.awt.*;
import org.w3c.dom.Document;
import org.w3c.dom.NodeList;
import org.w3c.dom.Node;
import org.w3c.dom.Element;

//start class
//Extends XMLReader as it is part of the XMLBookingReader class
public class XMLBookingReader extends XMLReader
{
	//Document for Bookings Reader
	//------------------------------------------------------------
	private Document aDoc;
	//------------------------------------------------------------
	
	//String for Bookings Reader
	//------------------------------------------------------------
	private String[][] data = new String[10][9];
	//------------------------------------------------------------
	
	//Integers for Bookings Reader
	//------------------------------------------------------------
	private int rowCounter = 0;
	private int columnCounter = 0;
	//------------------------------------------------------------
	
	//JTable and ScrollPane for Bookings Reader
	//------------------------------------------------------------
	private JTable bookingTable;
	private JScrollPane displayScrollPanel;
	//------------------------------------------------------------
	//================================================================================================================================================================================
	
	//Constructor --> bookingReader STRING
	public String[][] bookingReader()
	{		
		//Gathers information from ClientDetails.xml file, becomes a NodeList.
		aDoc = serverConnection("D:\\Program Files\\eclipse\\workspace\\Element011\\src\\ClientDetails.xml");
		System.out.println("Root element :" + aDoc.getDocumentElement().getNodeName());
		NodeList nList = aDoc.getElementsByTagName("clientbooking");
		System.out.println("----------------------------");
		
		//for loop for client data
		for (int temp = 0; temp < nList.getLength(); temp++)
		{
			//Node for NodeList
			Node nNode = nList.item(temp);
			System.out.println("\nCurrent Element :" + nNode.getNodeName());
			
			//Node gets attributes, text content from XML file
			if (nNode.getNodeType() == Node.ELEMENT_NODE)
			{
				Element eElement = (Element) nNode;
				String bookID_Table = eElement.getAttribute("ID");
				String aptName_Table = eElement.getElementsByTagName("apartmentname").item(0).getTextContent();
				String firstName_Table = eElement.getElementsByTagName("firstname").item(0).getTextContent();
				String lastName_Table = eElement.getElementsByTagName("lastname").item(0).getTextContent();
				String numGuests_Table = eElement.getElementsByTagName("numberguests").item(0).getTextContent();
				String startDate_Table = eElement.getElementsByTagName("startdate").item(0).getTextContent();
				String endDate_Table = eElement.getElementsByTagName("enddate").item(0).getTextContent();
				String catering_Table = eElement.getElementsByTagName("catering").item(0).getTextContent();
				
				//Data and Column counters for bookID_Table
				data[rowCounter][columnCounter] = bookID_Table;
				columnCounter = columnCounter + 1;
				
				//Data and Column counters for aptName_Table
				data[rowCounter][columnCounter] = aptName_Table;
				columnCounter = columnCounter + 1;
				
				//Data and Column counters for firstName_Table
				data[rowCounter][columnCounter] = firstName_Table;
				columnCounter = columnCounter + 1;
				
				//Data and Column counters for lastName_Table
				data[rowCounter][columnCounter] = lastName_Table;
				columnCounter = columnCounter + 1;
				
				//Data and Column counters for numGuests_Table
				data[rowCounter][columnCounter] = numGuests_Table;
				columnCounter = columnCounter + 1;
				
				//Data and Column counters for startDate_Table
				data[rowCounter][columnCounter] = startDate_Table;
				columnCounter = columnCounter + 1;
				
				//Data and Column counters for endDate_Table
				data[rowCounter][columnCounter] = endDate_Table;
				columnCounter = columnCounter + 1;
				
				//Data counters for catering_Table
				data[rowCounter][columnCounter] = catering_Table;
						
				//Debugging statements
				System.out.println("Booking ID: " + bookID_Table);
				System.out.println("First Name: " + firstName_Table);
				System.out.println("Last Name: " + lastName_Table);
				System.out.println("Start Date: " + startDate_Table);
				System.out.println("End Date: " + endDate_Table);
				System.out.println("Max Guests I want: " + numGuests_Table);
				System.out.println("Catering: " + catering_Table);			
			}// end if
			
			//Add 1 to counter
			rowCounter = rowCounter + 1;
			columnCounter = 0;
		}// end for
		//Returns client data
		return data;
	}//end method
	
	//Displays client table
	public void tableDisplay(String[][] dataTable, String columnTable[], JPanel displayPanel, JFrame displayFrame)
	{
			//Creates table for client
			bookingTable = new JTable(dataTable,columnTable);
			bookingTable.setBounds(30,40,1200,200);
			displayScrollPanel = new JScrollPane(bookingTable);
			
			displayPanel.add(displayScrollPanel);
			displayFrame.add(displayPanel);
			displayFrame.setVisible(true);
	}//end method	
}//end class

