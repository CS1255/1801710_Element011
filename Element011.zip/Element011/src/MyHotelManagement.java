/*************************************************************************/
//* Name: SID: 1801710                                                  *//
//* Task: Element 010 - Hotel Management System                         *//
//* Description: Hotel Management Main Code                             *//
//* Date: 17/05/2020                                                    *//
//*                                                                     *//
/************************************************************************/

//import packages
import java.awt.*;
import java.awt.event.*;
import java.io.File;
import javax.swing.*;
import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;
import org.w3c.dom.Document;
import org.w3c.dom.Element;
import org.w3c.dom.Node;
import org.w3c.dom.NodeList;

//start class
//Extends JFrame as it is part of the MyHotelManagement Class, 
//implements ActionListener for objects to receive actions
public class MyHotelManagement extends JFrame implements ActionListener
{
	//FlowLayout and BorderLayouts for MyHotelManagement
	private final FlowLayout myFlowLayout1;
	private final FlowLayout myFlowLayout2;
	private final FlowLayout myFlowLayout3;
	private final BorderLayout myBorderLayout1;
	private final BorderLayout myBorderLayout2;
	private final BorderLayout myBorderLayout2B;
	//------------------------------------------------------------
	
	//BorderLayout and FlowLayout for Booking
	private FlowLayout myFlowLayout_booking1; //Creates the Booking Frame
	private FlowLayout myFlowLayout_booking2; //Used for Booking Selections Panel (Booking Panel 3)
	private BorderLayout myBorderLayout_booking1; //Used for Booking Panel 1
	private BorderLayout myBorderLayout_booking2; //Used for Apartments Panel (Booking Panel 2)
	private BorderLayout myBorderLayout_booking3; //Used for Booking Selections Panel (Booking Panel 3), done through labels and text fields
	private BorderLayout myBorderLayout_booking3A;
	private BorderLayout myBorderLayout_booking3B;
	//------------------------------------------------------------
	
	//JPanels for MyHotelManagement
	private final JPanel myPanel1;
	private final JPanel myPanel2;
	private final JPanel myPanel2B;
	private final JPanel myPanel3;
	//------------------------------------------------------------
	
	//JPanels for apartment booking
	private JPanel myPanel_booking1;
	private JPanel myPanel_booking2;
	private JPanel myPanel_booking3;
	private JPanel myPanel_booking3A;
	private JPanel myPanel_booking3B;
	//------------------------------------------------------------
	
	//JLabels for apartment booking
	private JLabel myAptSelectionLabel; //label for apartment selections
	private JLabel myFirstNameLabel; //label for first name
	private JLabel myLastNameLabel; //label for last name
	private JLabel myMaxGuestsLabel; //label for max amount of guests
	private JLabel myCateringBookingLabel; //label for catering
	private JLabel myStartDateLabel; //label for start date
	private JLabel myEndDateLabel; //label for end date
	//------------------------------------------------------------
	
	//JTextFields for apartment booking
	private JTextField myAptSelectionTextField; //text field for apartment selections
	private JTextField myFirstNameTextField; //text field for first name
	private JTextField myLastNameTextField; //text field for last name
	private JTextField myMaxGuestsTextField; //text field for max amount of guests
	private JTextField myCateringBookingTextField; //text field for catering
	private JTextField myStartDateTextField; //text field for start date
	private JTextField myEndDateTextField; //text field for end date
	//------------------------------------------------------------
	
	//JLabel for login details
	private final JLabel myLoginLabel;
	private final JLabel myUsernameLabel;
	private final JLabel myPasswordLabel;
	//------------------------------------------------------------
	
	//JLabels for the Client Options
	private JLabel clientMenuOptionsLabel;
	//JTextField for the Client Options
	private JTextField clientMenuOptionsTextField;
	
	//javax.swing.Font for Client Menu Options
	private Font aClientFont;
	private Font aManagerFont;
	//JLabels for the Manager Options
	private JLabel managerMenuOptionsLabel;
	//JTextField for the Manager Options
	private JTextField managerMenuOptionsTextField;
	
	//JTextFields for login details
	private final JTextField myLoginTextField;
	private final JTextField myUsernameTextField;
	private final JTextField myPasswordTextField;
	private String myLoginOptionNumber = "";
	private String myClientMenuOptionNumber = "";
	private String myManagerMenuOptionNumber = "";
	private String myUsernameText = "";
	private String myPasswordText = "";
	//------------------------------------------------------------
	
	//booleans for login and client menu
	private boolean login = false;
	private int loginCounter = 0;
	private boolean clientMenuDisplayed = false;
	private boolean managerMenuDisplayed = false;
	private boolean clientBookingWriteReady = false;
	//------------------------------------------------------------
	
	//Login Details for Clients
	private String[][] clientLoginDetails = {{"John Smith", "1234"},{"Chester Shaw", "1234*"}};
	private String tempClientUsername = "";
	private String tempClientPassword = "";
	
	//Login Details for Managers
	private String[][] managerLoginDetails = {{"JohnBossy", "BBBB"},{"ChesterDaBoss", "BBBB*"}};
	private String tempManagerUsername = "";
	private String tempManagerPassword = "";
	
	
	
	//JFrame for booking
	private JFrame myBookingFrame;
	
	//Reads the class XMLApartmentsReader
	private XMLApartmentsReader myApartmentsReader;
	//Reads the class XMLBookingReader
	private XMLBookingReader myBookingReader;
	//Reads the class XMLBookingReader
	private XMLConfirmationReader myConfirmationReader;
	
	//Strings for Apartment data
	private String[][] myApartmentsData = new String[10][9];
	private String column[]={"Apartment ID", "Apartment Name", "Price per Night", "Start Date", "End Date", "Max Guests", "Number Beds", "Number Baths", "Living Room"};
	//Strings for Client data
	private String[][] myClientsData = new String[10][9];
	private String bookColumn[]={"Booking ID", "Apartment Name", "First Name", "Last Name", "Start Date", "End Date", "Max Guests I want", "Catering"};
	//Strings for Confirmation data
	private String[][] myConfirmData = new String[10][9];
	private String confirmColumn[]={"Booking ID", "First Name", "Last Name", "Max Guests I want", "Start Date", "End Date", "Apartment Name", "Number Beds", "Living Room", "Number Baths", "Catering"};
	
	//JPanel, JFrame and JScrollPane for display
	private JPanel myDisplayPanel;
	private JFrame myDisplayFrame;
	private JScrollPane myDisplayScrollPanel;
	
	//Document and reads the class XMLBookingWriter
	private Document writeDoc;
	private XMLBookingWriter myXMLBookingWriter;
	
	//Strings for client booking apartment details
	private String aClientBookingAptName = "";
	private String aClientBookingFirstName = "";
	private String aClientBookingLastName = "";
	private String aClientBookingMaxGuests = "";
	private String aClientBookingStartDate = "";
	private String aClientBookingEndDate = "";
	private String aClientBookingCatering = "";
	//------------------------------------------------------------
	
	//Files, Documents for XML
	//------------------------------------------------------------
	private File inputFile;
	private DocumentBuilder dBuilder;
	private DocumentBuilderFactory dbFactory;
	private Document aBookingDoc;
	//------------------------------------------------------------
	
	//JButton for Booking
	//------------------------------------------------------------
	private JButton myBookingButton;
	//------------------------------------------------------------
	//================================================================================================================================================================================
	
	//Constructor --> No-Argument
	public MyHotelManagement()
	{
		//LOGIN DETAILS
		//Creates Login layout for Chester's Hotel
		//------------------------------------------------------------------------------------------
		super("Chester's Hotel");
		myFlowLayout1 = new FlowLayout();
		myBorderLayout1 = new BorderLayout();
		myBorderLayout1.setHgap(10);
		myBorderLayout1.setVgap(10);
		myFlowLayout2 = new FlowLayout();
		myFlowLayout3 = new FlowLayout();
		myBorderLayout2 = new BorderLayout();
		myBorderLayout2B = new BorderLayout();
		
		myLoginLabel = new JLabel("Login Options (1: Client, 2: Manager)");
		myLoginTextField = new JTextField(50);
		myLoginTextField.addActionListener(this);
		
		
		setLayout(myFlowLayout1);
		
		myPanel1 = new JPanel();
		myPanel2 = new JPanel();
		myPanel2B = new JPanel();
		myPanel3 = new JPanel();
		
		
		myPanel1.setLayout(myBorderLayout1);
		myPanel1.setVisible(true);
		this.add(myPanel1);
		myPanel2.setLayout(myBorderLayout2);
		myPanel2.setVisible(true);
		myPanel2B.setLayout(myBorderLayout2B);
		myPanel2B.setVisible(true);
		myPanel1.add(myPanel2, BorderLayout.EAST);
		this.add(myPanel1);
		myPanel1.add(myPanel2B, BorderLayout.WEST);
		this.add(myPanel1);
		
		myPanel3.setLayout(myFlowLayout3);
		myPanel3.setVisible(true);
		myPanel1.add(myPanel3, BorderLayout.SOUTH);
		this.add(myPanel1);
		//------------------------------------------------------------------------------------------
		
		//Login Details Label and TextFields
		//------------------------------------------------------------------------------------------
		myLoginLabel.setVisible(true);
		myPanel2B.add(myLoginLabel, BorderLayout.NORTH);
		myPanel2B.setVisible(true);
		myPanel1.add(myPanel2B, BorderLayout.WEST);
		this.add(myPanel1);
		
		myLoginTextField.setSize(100, 100);
		myLoginTextField.setVisible(true);
		myPanel2.add(myLoginTextField, BorderLayout.NORTH);
		myPanel2.setVisible(true);
		myPanel1.add(myPanel2, BorderLayout.EAST);
		this.add(myPanel1);
		//------------------------------------------------------------------------------------------
		
		//Username Label and TextFields
		//------------------------------------------------------------------------------------------
		myUsernameLabel = new JLabel("Username: ");
		myUsernameTextField = new JTextField(50);
		myUsernameTextField.addActionListener(this);
		
		myUsernameLabel.setVisible(true);
		myPanel2B.add(myUsernameLabel, BorderLayout.CENTER);
		myPanel2B.setVisible(true);
		myPanel1.add(myPanel2B, BorderLayout.WEST);
		this.add(myPanel1);
		
		myUsernameTextField.setSize(100, 100);
		myUsernameTextField.setVisible(true);
		myPanel2.add(myUsernameTextField, BorderLayout.CENTER);
		myPanel2.setVisible(true);
		myPanel1.add(myPanel2, BorderLayout.EAST);
		this.add(myPanel1);
		//------------------------------------------------------------------------------------------
		
		//Password Label and TextFields
		//------------------------------------------------------------------------------------------
		myPasswordLabel = new JLabel("Password: ");
		myPasswordTextField = new JTextField(50);
		myPasswordTextField.addActionListener(this);
		
		myPasswordLabel.setVisible(true);
		myPanel2B.add(myPasswordLabel, BorderLayout.SOUTH);
		myPanel2B.setVisible(true);
		myPanel1.add(myPanel2B, BorderLayout.WEST);
		this.add(myPanel1);
		
		myPasswordTextField.setSize(100, 100);
		myPasswordTextField.setVisible(true);
		myPanel2.add(myPasswordTextField, BorderLayout.SOUTH);
		myPanel2.setVisible(true);
		myPanel1.add(myPanel2, BorderLayout.EAST);
		this.add(myPanel1);
		//------------------------------------------------------------------------------------------
		//================================================================================================================================================================================
		
		
		//CLIENT DETAILS
		//Apartment Selection Label and TextField
		//------------------------------------------------------------------------------------------
		myAptSelectionLabel = new JLabel("Apartment Name");
		myAptSelectionTextField = new JTextField(15);
		myAptSelectionTextField.addActionListener(this);
		//------------------------------------------------------------------------------------------
		
		//First Name Label and TextField
		//------------------------------------------------------------------------------------------
		myFirstNameLabel = new JLabel("First Name");
		myFirstNameTextField = new JTextField(15);
		myFirstNameTextField.addActionListener(this);
		//------------------------------------------------------------------------------------------
		
		//Last Name Label and TextField
		//------------------------------------------------------------------------------------------
		myLastNameLabel = new JLabel("Last Name");
		myLastNameTextField = new JTextField(15);
		myLastNameTextField.addActionListener(this);
		//------------------------------------------------------------------------------------------
		
		//Max Guests Label and TextField
		myMaxGuestsLabel = new JLabel("Max Guests");
		myMaxGuestsTextField = new JTextField(15);
		myMaxGuestsTextField.addActionListener(this);
		//------------------------------------------------------------------------------------------
		
		//Start Date Label and TextField
		//------------------------------------------------------------------------------------------
		myStartDateLabel = new JLabel("Start Date");
		myStartDateTextField = new JTextField(15);
		myStartDateTextField.addActionListener(this);
		//------------------------------------------------------------------------------------------
		
		//End Date Label and TextField
		//------------------------------------------------------------------------------------------
		myEndDateLabel = new JLabel("End Date");
		myEndDateTextField = new JTextField(15);
		myEndDateTextField.addActionListener(this);
		//------------------------------------------------------------------------------------------
		
		//Catering Label and TextField
		//------------------------------------------------------------------------------------------
		myCateringBookingLabel = new JLabel("Catering(Yes or No)");
		myCateringBookingTextField = new JTextField(15);
		myCateringBookingTextField.addActionListener(this);
		//------------------------------------------------------------------------------------------
		
		//Display Frame and Panel
		myDisplayFrame = new JFrame();
		myDisplayPanel = new JPanel();
		//================================================================================================================================================================================
	}
	
	
	//Constructor --> @Override Action
	public void actionPerformed(ActionEvent event)
	{
		
		myLoginOptionNumber = myLoginTextField.getText();
		//Debugging statement
		System.out.println(myLoginOptionNumber);
		
		myUsernameText = myUsernameTextField.getText();
		//Debugging statement
		System.out.println(myUsernameText);
		
		myPasswordText = myPasswordTextField.getText();
		//Debugging statement
		System.out.println(myPasswordText);
		
		//While loop for Usernames and Passwords
		while (login == false)
		{
			//for loop for Usernames and Passwords
			for(int i = 0; i<2; i++)
			{
				//Temp Client login details
				tempClientUsername = clientLoginDetails[i][0];
				tempClientPassword = clientLoginDetails[i][1];
				
				//Temp Manager login details
				tempManagerUsername = managerLoginDetails[i][0];
				tempManagerPassword = managerLoginDetails[i][1];
				
				
				//Debugging statement
				System.out.println("Welcome: " + tempClientUsername);
				//LOGIN OPITION 1 ---> Client Login
				if ((new String(myUsernameText).equals(tempClientUsername)) & new String(myPasswordText).equals(tempClientPassword) & new String(myLoginOptionNumber).equals("1"))
				{
					System.out.println("Client Login Successful!");
					JOptionPane.showMessageDialog(null, "Client Login Successful");
					login = true;
					
					//CLIENT OPTIONS MENU --> Creates and displays Options Menu for Client
					//PANEL 3 --> Client Options Menu
					StringBuilder buff = new StringBuilder();
					buff.append("<html><table>");
					buff.append(String.format("<tr><td align='left'>%s</td>"+ "</tr>", "CLIENT OPTIONS"));
					buff.append(String.format("<tr><td align='left'>%s</td>"+ "</tr>", "1. Do Your Booking"));
					buff.append(String.format("<tr><td align='left'>%s</td>"+ "</tr>", "2. Manage Your Booking"));
					buff.append(String.format("<tr><td align='left'>%s</td>"+ "</tr>", "3. EXIT"));
					buff.append("</table></html>");
					
					//Client Options Menu Font
					aClientFont = new Font("Arial", Font.ITALIC, 24);
					
					//Client Menu Options Label and TextFields
					//---------------------------------------------------------------------
					clientMenuOptionsLabel = new  JLabel(buff.toString());
					clientMenuOptionsLabel.setFont(aClientFont);
					myPanel3.add(clientMenuOptionsLabel, BorderLayout.NORTH);
					myPanel3.setVisible(true);
					myPanel1.add(myPanel3, BorderLayout.SOUTH);
					myPanel1.revalidate();
					myPanel1.repaint();
					this.add(myPanel1);
					
					clientMenuOptionsTextField = new JTextField(50);
					clientMenuOptionsTextField.addActionListener(this);
					myPanel3.add(clientMenuOptionsTextField, BorderLayout.SOUTH);
					myPanel3.setVisible(true);
					myPanel1.add(myPanel3, BorderLayout.SOUTH);
					myPanel1.revalidate();
					myPanel1.repaint();
					this.add(myPanel1);
					clientMenuDisplayed = true;
					//---------------------------------------------------------------------	
				}//end if
				//LOGIN OPITION 2 ---> Manager Login
				else if ((new String (myUsernameText).equals(tempManagerUsername)) & new String (myPasswordText).equals(tempManagerPassword) & new String (myLoginOptionNumber).equals("2"))
				{
					System.out.println("Manager Login Successful");
					JOptionPane.showMessageDialog(null, "Manager Login Successful");
					login = true;
					loginCounter = 3;
					
					//MANAGER OPTIONS MENU --> Creates and displays Options Menu for Manager
					//PANEL 3 --> Manager Options Menu
					StringBuilder managerBuff = new StringBuilder();
					managerBuff.append("<html><table>");
					managerBuff.append(String.format("<tr><td align='left'>%s</td>"+ "</tr>", "MANAGER OPTIONS"));
					managerBuff.append(String.format("<tr><td align='left'>%s</td>"+ "</tr>", "1. View all Bookings"));
					managerBuff.append(String.format("<tr><td align='left'>%s</td>"+ "</tr>", "2. Manage a Booking"));
					managerBuff.append(String.format("<tr><td align='left'>%s</td>"+ "</tr>", "3. EXIT"));
					managerBuff.append("</table></html>");
					
					//Manager Options Menu Font
					aManagerFont = new Font("Arial", Font.ITALIC, 24);
					
					//Manager Menu Options Label and TextFields
					//---------------------------------------------------------------------
					managerMenuOptionsLabel = new JLabel(managerBuff.toString());
					managerMenuOptionsLabel.setFont(aManagerFont);
					myPanel3.add(managerMenuOptionsLabel, BorderLayout.NORTH);
					myPanel3.setVisible(true);
					myPanel1.add(myPanel3, BorderLayout.SOUTH);
					myPanel1.revalidate();
					myPanel1.repaint();
					this.add(myPanel1);
					
					managerMenuOptionsTextField = new JTextField(50);
					managerMenuOptionsTextField.addActionListener(this);
					myPanel3.add(managerMenuOptionsTextField, BorderLayout.SOUTH);
					myPanel3.setVisible(true);
					myPanel1.add(myPanel3, BorderLayout.SOUTH);
					myPanel1.revalidate();
					myPanel1.repaint();
					this.add(myPanel1);
					//---------------------------------------------------------------------
				}//end else if
				else
				{ //If login = 0, then the login has failed
					if ((loginCounter==0) & (login==false))
					{
						loginCounter = loginCounter + 1;
						JOptionPane.showMessageDialog(this, "Login Failed!");
					}
				}//end else
			}//end for
		}//end while

		//CLIENT --> Do Booking Option
		if(clientMenuDisplayed == true)
		{
			if (new String(clientMenuOptionsTextField.getText()).equals("1"))
			{
				//Debugging statement
				System.out.println("Want to make a booking?");
				
				//Gathers data from other classes
				myApartmentsReader = new XMLApartmentsReader();
				myXMLBookingWriter = new XMLBookingWriter();
				
				//String [][] apartmentsReader()
				myApartmentsData = myApartmentsReader.apartmentsReader();
				
				
				
				//set up the new frame for the Booking
				myBookingFrame = new JFrame("Do Booking");
				myBookingFrame.setDefaultCloseOperation(JFrame.HIDE_ON_CLOSE);
				myBookingFrame.setSize(1200, 500);
				myBookingFrame.setVisible(true);
				
				//Creates and Displays Booking Options
				//---------------------------------------------------------------------
				myFlowLayout_booking1 = new FlowLayout(); 
				myBorderLayout_booking1 = new BorderLayout(); 
				myBorderLayout_booking2 = new BorderLayout(); 
				myBorderLayout_booking3 = new BorderLayout(); 
				myFlowLayout_booking2 = new FlowLayout(); 

				//Creates Booking Layout
				myBookingFrame.setLayout(myFlowLayout_booking1);
				
				myPanel_booking1 = new JPanel();
				myPanel_booking3 = new JPanel();
				myPanel_booking3A = new JPanel();
				myPanel_booking3B = new JPanel();
				myPanel_booking2 = new JPanel();
				
				myPanel_booking1.setLayout(myBorderLayout_booking1);
				myBookingFrame.add(myPanel_booking1);
				
				myPanel_booking2.setLayout(myBorderLayout_booking2);
				myPanel_booking2.setVisible(true);
				myPanel_booking1.add(myPanel_booking2, BorderLayout.NORTH);
				myBookingFrame.add(myPanel_booking1);
				
				myPanel_booking3.setLayout(myFlowLayout_booking2);
				myFlowLayout_booking2.setAlignment(FlowLayout.CENTER);
				myPanel_booking3.setVisible(true);
				myPanel_booking1.add(myPanel_booking3, BorderLayout.SOUTH);
				myBookingFrame.add(myPanel_booking1);
				
				//Displays table for Apartments
				myApartmentsReader.tableDisplay(myApartmentsData, column, myPanel_booking2, myBookingFrame);
				
				//If true, allow booking to be written
				clientBookingWriteReady = true;
				//---------------------------------------------------------------------
			}//end if
		}//end if
		
		//Writes booking details if they are true
		if (clientBookingWriteReady == true)
		{
			//Apartment Selection
			//---------------------------------------------------------------//
			myAptSelectionLabel.setVisible(true);
			myPanel_booking3.add(myAptSelectionLabel, BorderLayout.NORTH);
			myPanel_booking3.setVisible(true);
			myPanel_booking1.add(myPanel_booking3, BorderLayout.NORTH);
			myBookingFrame.add(myPanel_booking1);
			
			myAptSelectionTextField.setSize(15, 15);
			myAptSelectionTextField.setVisible(true);
			myPanel_booking3.add(myAptSelectionTextField, BorderLayout.CENTER);
			myPanel_booking3.setVisible(true);
			myPanel_booking1.add(myPanel_booking3, BorderLayout.NORTH);
			myBookingFrame.add(myPanel_booking1);
			//---------------------------------------------------------------//
			
			//First Name for booking Selection
			//---------------------------------------------------------------//
			myFirstNameLabel.setVisible(true);
			myPanel_booking3.add(myFirstNameLabel);
			myPanel_booking3.setVisible(true);
			myPanel_booking1.add(myPanel_booking3, BorderLayout.NORTH);
			myBookingFrame.add(myPanel_booking1);
			
			myFirstNameTextField.setSize(20, 15);
			myFirstNameTextField.setVisible(true);
			myPanel_booking3.add(myFirstNameTextField);
			myPanel_booking3.setVisible(true);
			myPanel_booking1.add(myPanel_booking3, BorderLayout.NORTH);
			myBookingFrame.add(myPanel_booking1);
			//---------------------------------------------------------------//
			
			//Last Name for booking Selection
			//---------------------------------------------------------------//
			myLastNameLabel.setVisible(true);
			myPanel_booking3.add(myLastNameLabel);
			myPanel_booking3.setVisible(true);
			myPanel_booking1.add(myPanel_booking3, BorderLayout.NORTH);
			myBookingFrame.add(myPanel_booking1);
			
			myLastNameTextField.setSize(15, 15);
			myLastNameTextField.setVisible(true);
			myPanel_booking3.add(myLastNameTextField);
			myPanel_booking3.setVisible(true);
			myPanel_booking1.add(myPanel_booking3, BorderLayout.NORTH);
			myBookingFrame.add(myPanel_booking1);
			//---------------------------------------------------------------//
			
			//Max Guests for booking Selection
			//---------------------------------------------------------------//
			myMaxGuestsLabel.setVisible(true);
			myPanel_booking3.add(myMaxGuestsLabel);
			myPanel_booking3.setVisible(true);
			myPanel_booking1.add(myPanel_booking3, BorderLayout.NORTH);
			myBookingFrame.add(myPanel_booking1);
			
			myMaxGuestsTextField.setSize(15, 15);
			myMaxGuestsTextField.setVisible(true);
			myPanel_booking3.add(myMaxGuestsTextField);
			myPanel_booking3.setVisible(true);
			myPanel_booking1.add(myPanel_booking3, BorderLayout.NORTH);
			myBookingFrame.add(myPanel_booking1);
			//---------------------------------------------------------------//
			
			//Start Date for booking Selection
			//---------------------------------------------------------------//
			myStartDateLabel.setVisible(true);
			myPanel_booking3.add(myStartDateLabel);
			myPanel_booking3.setVisible(true);
			myPanel_booking1.add(myPanel_booking3, BorderLayout.NORTH);
			myBookingFrame.add(myPanel_booking1);
			
			myStartDateTextField.setSize(15, 15);
			myStartDateTextField.setVisible(true);
			myPanel_booking3.add(myStartDateTextField);
			myPanel_booking3.setVisible(true);
			myPanel_booking1.add(myPanel_booking3, BorderLayout.NORTH);
			myBookingFrame.add(myPanel_booking1);
			//---------------------------------------------------------------//
			
			//End Date for booking Selection
			//---------------------------------------------------------------//
			myEndDateLabel.setVisible(true);
			myPanel_booking3.add(myEndDateLabel);
			myPanel_booking3.setVisible(true);
			myPanel_booking1.add(myPanel_booking3, BorderLayout.NORTH);
			myBookingFrame.add(myPanel_booking1);
			
			myEndDateTextField.setSize(20, 15);
			myEndDateTextField.setVisible(true);
			myPanel_booking3.add(myEndDateTextField);
			myPanel_booking3.setVisible(true);
			myPanel_booking1.add(myPanel_booking3, BorderLayout.NORTH);
			myBookingFrame.add(myPanel_booking1);
			//---------------------------------------------------------------//
			
			//Catering option for booking Selection
			//---------------------------------------------------------------//
			myCateringBookingLabel.setVisible(true);
			myPanel_booking3.add(myCateringBookingLabel);
			myPanel_booking3.setVisible(true);
			myPanel_booking1.add(myPanel_booking3, BorderLayout.NORTH);
			myBookingFrame.add(myPanel_booking1);
			
			myCateringBookingTextField.setSize(15, 15);
			myCateringBookingTextField.setVisible(true);
			myPanel_booking3.add(myCateringBookingTextField);
			myPanel_booking3.setVisible(true);
			myPanel_booking1.add(myPanel_booking3, BorderLayout.NORTH);
			myBookingFrame.add(myPanel_booking1);
			//---------------------------------------------------------------//
			
			//Booking button for booking selection
			myBookingButton = new JButton("Booking");
			myBookingButton.addActionListener(this);
			myBookingButton.setActionCommand("booking");
			myBookingButton.setVisible(true);
			myPanel_booking3.add(myBookingButton);
			myPanel_booking3.setVisible(true);
			myPanel_booking1.add(myPanel_booking3, BorderLayout.NORTH);
			myBookingFrame.add(myPanel_booking1);
			//---------------------------------------------------------------------
			
			//Writes booking details into ClientDetails.xml file.
			if("booking".equals(event.getActionCommand()))
			{
				aClientBookingAptName = myAptSelectionTextField.getText();
				aClientBookingFirstName = myFirstNameTextField.getText();
				aClientBookingLastName = myLastNameTextField.getText();
				aClientBookingMaxGuests = myMaxGuestsTextField.getText();
				aClientBookingStartDate = myStartDateTextField.getText();
				aClientBookingEndDate = myEndDateTextField.getText();
				aClientBookingCatering = myCateringBookingTextField.getText();
				
				writeDoc = myXMLBookingWriter.serverConnection();
				//bookingWriter(Document doc, String filenameToWrite, String clientFirstName, String clientLastName, String maxGuests,
				//String bookingStartDate, String bookingEndDate, String bookingCatering)
				myXMLBookingWriter.bookingWriter(writeDoc, "D:\\Program Files\\eclipse\\workspace\\Element011\\src\\ClientDetails.xml",
						aClientBookingAptName, aClientBookingFirstName, aClientBookingLastName, aClientBookingStartDate, aClientBookingEndDate, aClientBookingMaxGuests, aClientBookingCatering);
			}//end if	
		}//end if
		
		//CLIENT --> Manage a Booking
		if(clientMenuDisplayed == true)
		{
			if (new String(clientMenuOptionsTextField.getText()).equals("2"))
			{
				//Debugging statement
				System.out.println("Manage a booking?");
				
				//Gathers data from other classes
				myBookingReader = new XMLBookingReader();
				myXMLBookingWriter = new XMLBookingWriter();
				
				//String [][] apartmentsReader()
				myClientsData = myBookingReader.bookingReader();
						
				//set up the new frame for the Booking
				myBookingFrame = new JFrame("Manage Booking");
				myBookingFrame.setDefaultCloseOperation(JFrame.HIDE_ON_CLOSE);
				myBookingFrame.setSize(1200, 500);
				myBookingFrame.setVisible(true);
				
				//Creates and Displays Booking Options
				//---------------------------------------------------------------------
				myFlowLayout_booking1 = new FlowLayout();
				myBorderLayout_booking1 = new BorderLayout(); 
				myBorderLayout_booking2 = new BorderLayout();
				myBorderLayout_booking3 = new BorderLayout(); 
				myFlowLayout_booking2 = new FlowLayout();

				
				//Creates Booking Layout
				myBookingFrame.setLayout(myFlowLayout_booking1);
				
				myPanel_booking1 = new JPanel();
				myPanel_booking3 = new JPanel();
				myPanel_booking3A = new JPanel();
				myPanel_booking3B = new JPanel();
				myPanel_booking2 = new JPanel();
				
				myPanel_booking1.setLayout(myBorderLayout_booking1);
				myBookingFrame.add(myPanel_booking1);
				
				myPanel_booking2.setLayout(myBorderLayout_booking2);
				myPanel_booking2.setVisible(true);
				myPanel_booking1.add(myPanel_booking2, BorderLayout.NORTH);
				myBookingFrame.add(myPanel_booking1);
				
				myPanel_booking3.setLayout(myFlowLayout_booking2);
				myFlowLayout_booking2.setAlignment(FlowLayout.CENTER);
				myPanel_booking3.setVisible(true);
				myPanel_booking1.add(myPanel_booking3, BorderLayout.SOUTH);
				myBookingFrame.add(myPanel_booking1);
				
				//Displays table for Booking
				myBookingReader.tableDisplay(myClientsData, bookColumn, myPanel_booking2, myBookingFrame);
				
				//If true, allow booking to be written
				clientBookingWriteReady = true;
				//---------------------------------------------------------------------
			}//end if
		}//end if
		
		//Writes booking details if they are true
		if (clientBookingWriteReady == true)
		{
			//Writes booking details into ClientDetails.xml file.
			if("booking".equals(event.getActionCommand()))
			{
				aClientBookingAptName = myAptSelectionTextField.getText();
				aClientBookingFirstName = myFirstNameTextField.getText();
				aClientBookingLastName = myLastNameTextField.getText();
				aClientBookingMaxGuests = myMaxGuestsTextField.getText();
				aClientBookingStartDate = myStartDateTextField.getText();
				aClientBookingEndDate = myEndDateTextField.getText();
				aClientBookingCatering = myCateringBookingTextField.getText();
				
				writeDoc = myXMLBookingWriter.serverConnection();
				//bookingWriter(Document doc, String filenameToWrite, String clientFirstName, String clientLastName, String maxGuests,
				//String bookingStartDate, String bookingEndDate, String bookingCatering)
				myXMLBookingWriter.bookingWriter(writeDoc, "D:\\Program Files\\eclipse\\workspace\\Element011\\src\\ClientDetails.xml",
						aClientBookingAptName, aClientBookingFirstName, aClientBookingLastName, aClientBookingStartDate, aClientBookingEndDate, aClientBookingMaxGuests, aClientBookingCatering);
			}//end if	
		}//end if
	}//end method
}//end class
