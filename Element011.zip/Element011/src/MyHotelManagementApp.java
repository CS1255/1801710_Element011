/*************************************************************************/
//* Name: SID: 1801710                                                  *//
//* Task: Element 010 - Hotel Management System                         *//
//* Description: Hotel Management Application                           *//
//* Date: 17/05/2020                                                    *//
//*                                                                     *//
/************************************************************************/

//import java packages
import javax.swing.JFrame;

//start class
public class MyHotelManagementApp 
{
	//Declares and initialises Class 
	private static MyHotelManagement myHMS;
		//Method Main
		public static void main(String[] args)
			{
				//Reads MyHotelManagement code
				myHMS = new MyHotelManagement();
				myHMS.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
				myHMS.setSize(1200, 400);
				myHMS.setVisible(true);
			}	
}//end class
