/*************************************************************************/
//* Name: SID: 1801710                                                  *//
//* Task: Element 010 - Hotel Management System                         *//
//* Description: XML Apartments Reader                                  *//
//* Date: 17/05/2020                                                    *//
//*                                                                     *//
/************************************************************************/

//import packages
import java.io.File;
import javax.xml.parsers.DocumentBuilderFactory;
import javax.xml.parsers.DocumentBuilder;
import javax.swing.*;
import java.awt.*;
import org.w3c.dom.Document;
import org.w3c.dom.NodeList;
import org.w3c.dom.Node;
import org.w3c.dom.Element;

//start class
//Extends XMLReader as it is part of the XMLApartmentsReader class
public class XMLApartmentsReader extends XMLReader 
{
	//Document for Apartments Reader
	//------------------------------------------------------------
	private Document aDoc;
	//------------------------------------------------------------
	
	//String for Apartments Reader
	//------------------------------------------------------------
	private String[][] data = new String[10][9];
	//------------------------------------------------------------
	
	//Integers for Apartments Reader
	//------------------------------------------------------------
	private int rowCounter = 0;
	private int columnCounter = 0;
	//------------------------------------------------------------
	
	//JTable and ScrollPane for Apartments Reader
	private JTable apartmentsTable;
	private JScrollPane displayScrollPanel;
	//------------------------------------------------------------
	//================================================================================================================================================================================
	
	//Constructor --> apartmentsReader STRING
	public String[][] apartmentsReader()
	{	
		//Gathers information from Apartments.xml file, becomes a NodeList.
		aDoc = serverConnection("D:\\Program Files\\eclipse\\workspace\\Element011\\src\\Apartments.xml");
		System.out.println("Root element :" + aDoc.getDocumentElement().getNodeName());
		NodeList nList = aDoc.getElementsByTagName("apartment");
		System.out.println("----------------------------");
		
		//for loop for apartments data
		for (int temp = 0; temp < nList.getLength(); temp++)
		{
			//Node for NodeList
			Node nNode = nList.item(temp);
			System.out.println("\nCurrent Element :" + nNode.getNodeName());
			
			//Node gets attributes, text content from XML file
			if (nNode.getNodeType() == Node.ELEMENT_NODE)
			{
				Element eElement = (Element) nNode;
				String aptID_Table = eElement.getAttribute("ID");
				String aptName_Table = eElement.getElementsByTagName("apartmentname").item(0).getTextContent();
				String price_Table = eElement.getElementsByTagName("price").item(0).getTextContent();
				String startDate_Table = eElement.getElementsByTagName("startdate").item(0).getTextContent();
				String endDate_Table = eElement.getElementsByTagName("enddate").item(0).getTextContent();
				String maxGuests_Table = eElement.getElementsByTagName("maxguests").item(0).getTextContent();
				String numBeds_Table = eElement.getElementsByTagName("numberbeds").item(0).getTextContent();
				String numBaths_Table = eElement.getElementsByTagName("numberbaths").item(0).getTextContent();
				String livingRoom_Table = eElement.getElementsByTagName("livingroom").item(0).getTextContent();
				
				//Data and Column counters for aptID_Table
				data[rowCounter][columnCounter] = aptID_Table;
				columnCounter = columnCounter + 1;
				
				//Data and Column counters for aptName_Table
				data[rowCounter][columnCounter] = aptName_Table;
				columnCounter = columnCounter + 1;
				
				//Data and Column counters for price_Table
				data[rowCounter][columnCounter] = price_Table;
				columnCounter = columnCounter + 1;
				
				//Data and Column counters for startDate_Table
				data[rowCounter][columnCounter] = startDate_Table;
				columnCounter = columnCounter + 1;
				
				//Data and Column counters for endDate_Table
				data[rowCounter][columnCounter] = endDate_Table;
				columnCounter = columnCounter + 1;
				
				//Data and Column counters for maxGuests_Table
				data[rowCounter][columnCounter] = maxGuests_Table;
				columnCounter = columnCounter + 1;
				
				//Data and Column counters for numBeds_Table
				data[rowCounter][columnCounter] = numBeds_Table;
				columnCounter = columnCounter + 1;
				
				//Data and Column counters for numBaths_Table
				data[rowCounter][columnCounter] = numBaths_Table;
				columnCounter = columnCounter + 1;
				
				//Data counters for livingRoom_Table
				data[rowCounter][columnCounter] = livingRoom_Table;
				
				
				//Debugging statements
				System.out.println("Apartment ID: " + aptID_Table);
				System.out.println("Price per Night: " + price_Table);
				System.out.println("Start Date: " + startDate_Table);
				System.out.println("End Date: " + endDate_Table);
				System.out.println("Max number of guests: " + maxGuests_Table);
				System.out.println("Number of Bedrooms: " + numBeds_Table);
				System.out.println("Number of Bathrooms: " + numBaths_Table);
				System.out.println("Separate Living Room: " + livingRoom_Table);			
			}// end if
			
			//Add 1 to counter
			rowCounter = rowCounter + 1;
			columnCounter = 0;
		}// end for
		//Returns apartment data
		return data;
	}//end method
	
	//Displays apartments table
	public void tableDisplay(String[][] dataTable, String columnTable[], JPanel displayPanel, JFrame displayFrame)
	{
			//Creates table for apartments
			apartmentsTable = new JTable(dataTable,columnTable);
			apartmentsTable.setBounds(30,40,1200,200);
			displayScrollPanel = new JScrollPane(apartmentsTable);
			
			displayPanel.add(displayScrollPanel);		
			displayFrame.add(displayPanel);
			displayFrame.setVisible(true);
	}//end method
}//end class
