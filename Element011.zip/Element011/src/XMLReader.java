/*************************************************************************/
//* Name: SID: 1801710                                                  *//
//* Task: Element 010 - Hotel Management System                         *//
//* Description: XML Reader                                             *//
//* Date: 17/05/2020                                                    *//
//*                                                                     *//
/************************************************************************/

//import packages
import java.io.File;
import javax.xml.parsers.DocumentBuilderFactory;
import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JTable;
import javax.xml.parsers.DocumentBuilder;
import org.w3c.dom.Document;
import org.w3c.dom.NodeList;
import org.w3c.dom.Node;
import org.w3c.dom.Element;

//start class
public abstract class XMLReader 
{
	//Documents and File for XMLReader
	//------------------------------------------------------------------------------------------
	private File inputFile;
	private DocumentBuilder dBuilder;
	private DocumentBuilderFactory dbFactory;
	private Document doc;
	//------------------------------------------------------------------------------------------
	
	//Constructor --> serverConnection
	public Document serverConnection(String filename)
	{
		//try for building Reader
		try {
			//filename uses filepath i.e. C//Drive//etc
			inputFile = new File(filename);
			dbFactory = DocumentBuilderFactory.newInstance();
			dBuilder = dbFactory.newDocumentBuilder();
			//doc = new Document(); 
			//Might cause an error to occur
			doc = dBuilder.parse(inputFile);
			doc.getDocumentElement().normalize();
		} 
		catch (Exception e) 
		{
			e.printStackTrace();
		}//end try...catch
		//Returns document
		return doc;
	}//end method
	
	//Displays table for Reader
	abstract void tableDisplay(String[][] aDataTable, String aColumn[], JPanel displayPanel, JFrame displayFrame);
}//end class


