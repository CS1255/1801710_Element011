/*************************************************************************/
//* Name: SID: 1801710                                                  *//
//* Task: Element 010 - Hotel Management System                         *//
//* Description: XML Booking Writer		                                *//
//* Date: 17/05/2020                                                    *//
//*                                                                     *//
/************************************************************************/

//import packages
import javax.xml.parsers.DocumentBuilderFactory;
import javax.swing.JOptionPane;
import javax.xml.parsers.DocumentBuilder;
import javax.xml.transform.Transformer;
import javax.xml.transform.TransformerFactory;
import javax.xml.transform.dom.DOMSource;
import javax.xml.transform.stream.StreamResult;
import org.w3c.dom.Attr;
import org.w3c.dom.Document;
import org.w3c.dom.Element;
import java.io.File;

//start class
//Extends XMLWriter as it is part of the XMLBookingWriter Class
public class XMLBookingWriter extends XMLWriter
{
	//Elements for Booking Writer --> Client Details
	//------------------------------------------------------------
	private Element rootElement;
	private Element theBooking;
	private Element theApartmentName;
	private Element theFirstName;
	private Element theLastName;
	private Element theMaxGuests;
	private Element theStartDate;
	private Element theEndDate;
	private Element theCatering;
	//------------------------------------------------------------
	
	//Attribute for Booking Writer --> Client Details
	//------------------------------------------------------------
	private Attr attr;
	//------------------------------------------------------------
	
	//Transformers, DOMSource and StreamResult for XML
	//------------------------------------------------------------
	private TransformerFactory transformerFactory;
	private Transformer transformer;
	private DOMSource source;
	private StreamResult result;
	private StreamResult consoleResult;
	//------------------------------------------------------------
	
	//Integer for Booking ID --> Client
	//------------------------------------------------------------
	private int BID = 101;
	//------------------------------------------------------------
	//================================================================================================================================================================================
	
	//Constructor --> BookingWriter
	public void bookingWriter(Document doc, String filenameToWrite, String clientApartmentName, String clientFirstName, String clientLastName, String maxGuests, 
			String bookingStartDate, String bookingEndDate, String bookingCatering)
	{
		try
		{
			//ELEMENT --> Root
			rootElement = doc.createElement("clientsbookings");
			doc.appendChild(rootElement);
			
			//ELEMENT --> Bookings
			theBooking = doc.createElement("clientbooking");
			rootElement.appendChild(theBooking);
			
			//Attribute becomes Element
			attr = doc.createAttribute("ID");
			
			//BOOKING ID --> Security
			BID = BID + 1;
			attr.setValue(Integer.toString(BID));
			JOptionPane.showMessageDialog(null, "Your booking ID is: " + BID);
			
			theBooking.setAttributeNode(attr);
			
			//ELEMENT --> Bookings: Apartment Name
			theApartmentName = doc.createElement("apartmentname");
			theApartmentName.appendChild(doc.createTextNode(clientApartmentName));
			theBooking.appendChild(theApartmentName);
			
			//ELEMENT --> Bookings: FirstName
			theFirstName = doc.createElement("firstname");
			theFirstName.appendChild(doc.createTextNode(clientFirstName));
			theBooking.appendChild(theFirstName);
			
			//ELEMENT --> Bookings: Last Name
			theLastName = doc.createElement("lastname");
			theLastName.appendChild(doc.createTextNode(clientLastName));
			theBooking.appendChild(theLastName);
			
			//ELEMENT --> Bookings: Max Guests
			theMaxGuests = doc.createElement("numberguests");
			theMaxGuests.appendChild(doc.createTextNode(maxGuests));
			theBooking.appendChild(theMaxGuests);
			
			//ELEMENT --> Bookings: Start Date
			theStartDate = doc.createElement("startdate");
			theStartDate.appendChild(doc.createTextNode(bookingStartDate));
			theBooking.appendChild(theStartDate);
			
			//ELEMENT --> Bookings: End Date
			theEndDate = doc.createElement("enddate");
			theEndDate.appendChild(doc.createTextNode(bookingEndDate));
			theBooking.appendChild(theEndDate);
			
			//ELEMENT --> Bookings: Catering
			theCatering = doc.createElement("catering");
			theCatering.appendChild(doc.createTextNode(bookingCatering));
			theBooking.appendChild(theCatering);
			
			//Writes content into XML File
			transformerFactory = TransformerFactory.newInstance();
			transformer = transformerFactory.newTransformer();

			source = new DOMSource(doc);
			
			result = new StreamResult(new File(filenameToWrite));
			transformer.transform(source, result);
			
			//TESTING --> Output
			consoleResult = new StreamResult(System.out);
			transformer.transform(source, consoleResult);
		}
		catch (Exception e)
		{
			e.printStackTrace();
		}//end try...catch
	}//end method
}//end class

